#define _USE_MATH_DEFINES
#include <cmath>
#include <iostream>
using namespace std;
int main()
{
	int n;
	cout << "Nhap so canh cua da giac deu = ";
	cin >> n;
	float r;
	cout << "Nhap ban kinh = ";
	cin >> r;
	float P = 2 * n * sin(M_PI / n);
	cout << "Chu vi da giac deu noi tiep duong tron = " << P;
	return 0;
}