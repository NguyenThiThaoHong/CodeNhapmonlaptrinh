#include <iostream>
using namespace std;
int main()
{
	int a, b, temp;
	cout << "Nhap a = ";
	cin >> a;
	cout << "Nhap b = ";
	cin >> b;
	temp = a;
	a = b;
	b = temp;
	cout << "Sau khi hoan vi: " << a << " " << b;
	return 0;
}