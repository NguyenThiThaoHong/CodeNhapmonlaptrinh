#include <iostream>
#include <cmath>
using namespace std;
int main()
{
	int n;
	cout << "Nhap n = ";
	cin >> n;
	int at = n;
	cout << n << " ";
	while (at >= 2)
	{
		if (at % 2 != 0)
			at = at / 2;
		else
			at = 3 * at + 1;
		cout <<at << " ";
	}
	return 0;
}