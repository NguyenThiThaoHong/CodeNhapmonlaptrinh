#include <iostream>
#include <cmath>
using namespace std;
int main()
{
	int a;
	cout << "Nhap a = ";
	cin >> a;
    int b;
	cout << "Nhap b = ";
	cin >> b;
	float x = 1;
	if (a == 0)
	{
		if (b == 0)
			cout << "VSN";
		else
			cout << "VN";
	}
	else
		float x = -b / a;
		cout << "nghiem x=" <<  x;
	return 0;
}