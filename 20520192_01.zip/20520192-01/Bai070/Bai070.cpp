#include <iostream>
#include <cmath>
using namespace std;
int main()
{
	float x;
	cout << "Nhap x = ";
	cin >> x;
	int n;
	cout << "Nhap n = ";
	cin >> n;
	int S = 0;
	int T = 1;
	int i = 2;
	while (i <= 2 * n)
	{
		T *= pow(x, 2);
		S += T;
		i += 2;
	}
	cout << "Tong S = " << S;
	return 0;
}