#include <iostream>
#include <cmath>
using namespace std;
int main()
{
	float xA, yA, xB, yB, xC, yC;
	cout << "Nhap xA = ";
	cin >> xA;
	cout << "Nhap yA = ";
	cin >> yA;
	cout << "Nhap xB = ";
	cin >> xB;
	cout << "Nhap yB = ";
	cin >> yB;
	cout << "Nhap xC = ";
	cin >> xC;
	cout << "Nhap yC = ";
	cin >> yC;
	float AB = sqrt(pow(xB - xA, 2) + pow(yB - yA, 2));
	float AC = sqrt(pow(xC - xA, 2) + pow(yC - yA, 2));
	float BC = sqrt(pow(xC - xB, 2) + pow(yC - yB, 2));
	if (AB > abs(BC - AC) && AB < BC + AC)
		cout << "La tam giac";
	else
		cout << "Khong la tam giac";
	return 0;
}