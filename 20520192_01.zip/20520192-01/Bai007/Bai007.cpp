#include <iostream>
#include <cmath>
using namespace std;
int main()
{
	float F;
	cout << "Nhap nhiet do theo F = ";
	cin >> F;
	float C = (float)5 / 9 * F - 32;
	cout << "Nhiet do theo C = " << C;
	return 0;
}