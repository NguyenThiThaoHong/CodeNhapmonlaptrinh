#include <iostream>
#include <cmath>
using namespace std;
int main()
{
	float S = 0, T = 1, e = 1;
	int i = 1;
	while (e >= pow(10, -6))
	{
		T = T * i;
		e = 1 / T;
		S = S + e;
		i = i + 1;
	}
	cout << "e " << S;
	return 1;
}