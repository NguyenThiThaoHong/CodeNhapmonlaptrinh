#include <iostream>
#include <cmath>
using namespace std;
int main()
{
	float S = 3, e = 1;
	int i = 2, dau = 1;
	while (e >= pow(10, -6))
	{
		e = (float)4 / (i * (i + 1) * (i + 2));
		S = S + dau * e;
		i = i + 2;
		dau = -dau;
	}
	cout << "pi = " << S;
	return 0;
}