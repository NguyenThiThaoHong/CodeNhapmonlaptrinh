#include <iostream>
#include <cmath>
using namespace std;
int main()
{
	int n;
	cout << "Nhap n = ";
	cin >> n;
	n = abs(n);
	int lc = n % 10;
	int t = n;
	int dv = 0;
	while (t != 0)
	{
		dv = t % 10;
		if (dv > lc)
			lc = dv;
		t = t / 10;
	}
	cout << "chu so lon nhat :" << lc;
	return 0;
}