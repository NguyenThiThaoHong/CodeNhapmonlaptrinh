#include <iostream>
#include <cmath>
using namespace std;
int main()
{
	float S = 0, T = 1, e = 1;
	int  i = 1, dau = 1;
	while (e >= pow(10, -6))
	{
		e = (float) 4 / i;
		S = S + dau* e;
		i = i + 2;
		dau = -dau;
	}
	cout << "pi= " << S;
	return 1;
}