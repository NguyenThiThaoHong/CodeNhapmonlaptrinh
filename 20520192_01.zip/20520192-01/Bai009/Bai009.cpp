#define _USE_MATH_DEFINES
#include <iostream>
#include <cmath>
using namespace std;
int main()
{
	int n;
	cout << "Nhap so canh cua da giac deu = ";
	cin >> n;
	float r;
	cout << "Nhap ban kinh = ";
	cin >> r;
	float S = (float)1 / 2 * n * pow(r, 2) * sin(2 * M_PI / n);
	cout << "Dien tich da giac deu noi tiep duong tron = " << S;
	return 0;
}