#include <iostream>
#include <cmath>
using namespace std;
int main()
{
	float n;
	cout << "nhap n= ";
	cin >> n;
	int att = -1, at = 3;
	int ahh = 0, i = 2;
	while (i <= n)
	{
		ahh = 5*at + 6 * att ;
		i = i + 1;
		att = at;
		at = ahh;
	}
	cout << "so hang thu n" << ahh;
	return 1;
}