#include <iostream>
#include <cmath>
using namespace std;
int main()
{
	int a;
	cout << "Nhap a = ";
	cin >> a;
	int b;
	cout << "Nhap b = ";
	cin >> b;
	int c;
	cout << "Nhap c = ";
	cin >> c;
	float dt = pow(b, 2) - 4 * a * c;
	float x1, x2;
	if (dt != 0)
		if (dt > 0)
		{
			float x1 = (-b + sqrt(dt)) / (2 * a);
			float x2 = (-b - sqrt(dt)) / (2 * a);
			cout << x1 << " " << x2;
		}
		else
			cout << "PTVN";
	else
		cout << "nghiem x1=x2=" - b / 2 * a;
	return 0;
}