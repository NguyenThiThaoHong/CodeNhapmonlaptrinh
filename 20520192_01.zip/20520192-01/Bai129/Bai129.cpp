#include <iostream>
#include <cmath>
using namespace std;
int main()
{
	float a, b, c;
	cout << "Nhap a = ";
	cin >> a;
	cout << "Nhap b = ";
	cin >> b;
	cout << "Nhap c = ";
	cin >> c;
	if (a > b)
	{
		int temp = a;
		a = b;
		b = temp;
	}
	if (a > c)
	{
		int temp1 = a;
		a = c;
		c = temp1;
	}
	if (b > c)
	{
		int temp2 = b;
		b = c;
		c = temp2;
	}
	cout << "Thu tu tang dan la: " << a << " " << b << " " << c;
	return 0;
}