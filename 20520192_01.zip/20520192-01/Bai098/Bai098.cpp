#include <iostream>
#include <cmath>
using namespace std;
int main()
{
	int n;
	cout << "Nhap n = ";
	cin >> n;
	float S = 0, T = 1;
	int i = 2;
	while (i <= n)
	{
		S = pow(i + S, (float)1 / i);
		i = i + 1;
	}
	cout << "Tong S = " << S;
	return 0;
}