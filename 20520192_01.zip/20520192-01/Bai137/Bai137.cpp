#include <iostream>
#include <cmath>
using namespace std;
int main()
{
	float x;
	cout << "Nhap x = ";
	cin >> x;
	float S;
	if (x >= 5)
		S = 2 * pow(x, 2) + 5 * x + 9;
	else
		S = -2 * pow(x, 2) + 4 * x - 9;
	cout << "f(x) = " << S;
	return 0;
}