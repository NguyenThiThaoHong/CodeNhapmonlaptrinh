#include <iostream>
#include <cmath>
using namespace std;
int main()
{
	float x;
	cout << "Nhap x = ";
	cin >> x;
	int n;
	cout << "Nhap n = ";
	cin >> n;
	float S = 1;
	float T = 1;
	int i = 1;
	while (i <= n)
	{
		T *= x;
		S += (i + 1) * T;
		i += 1;
	}
	cout << "Tong S = " << S;
	return 0;
}