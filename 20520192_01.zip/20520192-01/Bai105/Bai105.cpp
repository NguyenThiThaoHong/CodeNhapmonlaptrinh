#include <iostream>
#include <cmath>
using namespace std;
int main()
{
	float S = 1, T = 0;
	int i = 1;
	float e = 1;
	while (e >= pow(10, -6))
	{
		T = T + i;
		e = (float)1 / T;
		S = S + e;
		i = i + 1;
	}
	cout << "Tong S = " << S;
	return 0;
}