#include <iostream>
#include <cmath>
using namespace std;
int main()
{
	float x;
	cout << "Nhap x = ";
	cin >> x;
	float sinx = x, T = x, e = 1;
	int M = 1, i = 2, dau = -1;
	while (e >= pow(10, -6))
	{
		T = T * pow(x, 2);
		M = M * i * (i - 1);
		e = (float)T / M;
		sinx = sinx + dau * e;
		i = i + 2;
		dau = -dau;
	}
	cout << "sin(x) = " << sinx;
	return 0;
}