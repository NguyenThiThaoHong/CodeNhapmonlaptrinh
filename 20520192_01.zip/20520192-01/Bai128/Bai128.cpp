#include <iostream>
#include <cmath>
using namespace std;
int main()
{
	float a, b;
	cout << "Nhap a = ";
	cin >> a;
	cout << "Nhap b = ";
	cin >> b;
	if (a > b)
	{
		int temp = a;
		a = b;
		b = temp;
	}
	cout << "Thu tu tang dan la: " << a << " " << b;
	return 0;
}