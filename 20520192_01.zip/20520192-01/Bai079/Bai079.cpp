#include <iostream>
#include <cmath>
using namespace std;
int main()
{
	int n;
	cout << "Nhap n = ";
	cin >> n;
	long S = 0;
	int M = 1;
	int i = 1;
	while (i <= n)
	{
		M *= i;
		S += i * M;
		i += 1;
	}
	cout << "Tong S = " << S;
	return 0;
}