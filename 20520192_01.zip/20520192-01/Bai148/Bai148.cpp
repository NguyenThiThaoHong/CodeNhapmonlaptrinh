#include <iostream>
#include <cmath>
using namespace std;
int main()
{
	int n;
	cout << "Nhap so nguyen duong n = ";
	cin >> n;
	n = abs(n);
	int flag = 1;
	int t = n;
	while (t != 0)
	{
		int dv = t % 10;
		if (n % 2 != 0)
			flag = 0;
		t = t / 10;
	}
	if (flag == 1)
		cout << "Toan chan";
	else
		cout << "Khong toan chan";
	return 0;
}#include <iostream>
#include <cmath>
using namespace std;
int main()
{
	int n;
	cout << "Nhap n = ";
	cin >> n;
	int flag = 0, t = n, dv = 0;
	while (t != 0)
	{
		dv = t % 10;
		if (dv % 2 != 0)
			flag = 1;
		t = t / 10;
	}
	if (flag == 0)
		cout << "toan chan";
	else
		cout << "ko ";
	return 1;

}
