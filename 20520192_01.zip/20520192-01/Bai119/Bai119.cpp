#include <iostream>
#include <cmath>
using namespace std;
int main()
{
	int n;
	cout << "Nhap n = ";
	cin >> n;
	float at = 2, ahh;
	int i = 2;
	while (i <= n)
	{
		ahh = (pow(at, 2) + 2) / (2 * at);
		i = i + 1;
		at = ahh;
	}
	cout << "So hang thu " << n << " = " << ahh;
	return 0;
}