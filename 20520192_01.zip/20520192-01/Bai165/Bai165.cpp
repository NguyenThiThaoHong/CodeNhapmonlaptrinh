#include <iostream>
#include <cmath>
using namespace std;
int main()
{
	int n;
	cout << "Nhap n = ";
	cin >> n;
	int S = 1;
	int k = 0;
	while (S < n)
	{
		S = S * 2;
		k = k + 1;
	}
	cout << "So nguyen thoa man yeu cau bai toan la: " << k - 1;
	return 0;
}