#include <iostream>
#include <cmath>
using namespace std;
int main()
{
	int n;
	cout << "Nhap n = ";
	cin >> n;
	float S = 0, i = 1;
	while (i <= n)
	{
		S += sqrt(1 + 1 / pow(i, 2) + 1 / pow(i + 1, 2));
		i += 1;
	}
	cout << "S = " << S;
	return 0;
}