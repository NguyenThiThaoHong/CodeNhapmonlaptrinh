#include <iostream>
#include <cmath>
using namespace std;
int main()
{
	float r;
	cout << "Nhap ban kinh = ";
	cin >> r;
	float Sxq = 4 * 3.14 * pow(r, 2);
	cout << "Dien tich xung quanh = " << Sxq;
	return 0;
}