#include <iostream>
#include <cmath>
using namespace std;
int main()
{
	float r;
	cout << "Nhap ban kinh = ";
	cin >> r;
	float C = 2 * 3.14 * r;
	cout << "Chu vi = " << C;
	return 1;
}