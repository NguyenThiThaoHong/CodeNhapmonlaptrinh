#include <iostream>
#include <cmath>
using namespace std;
int main()
{
	float n;
	cout << "nhap n= ";
	cin >> n;
	int at = 2;
	int ahh = 0, i = 2;
	while (i<=n)
	{
		ahh = at + 2 * i + 1;
		i = i + 1;
		at = ahh;
	}
	cout << "so hang thu n" << ahh;
	return 1;
}