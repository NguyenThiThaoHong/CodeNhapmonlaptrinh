#include <iostream>
#include <cmath>
using namespace std;
int main()
{
	float x;
	cout << "Nhap x = ";
	cin >> x;
	int n;
	cout << "Nhap n = ";
	cin >> n;
	float S = 1;
	float T = 1;
	int M = 1;
	int i = 2;
	while (i <= 2 * n)
	{
		T *= pow(x, 2);
		M *= i * (i - 1);
		S += (float)T / M;
		i += 2;
	}
	cout << "Tong S = " << S;
	return 0;
}