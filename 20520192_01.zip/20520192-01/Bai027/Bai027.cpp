#include <iostream>
using namespace std;
int main()
{
	int n;
	cout << "Nhap n = ";
	cin >> n;
	int S = 0;
	int i = 0;
	while (i <= n)
	{
		S += i;
		i += 1;
	}
	cout << "S = " << S;
	return 0;
}












