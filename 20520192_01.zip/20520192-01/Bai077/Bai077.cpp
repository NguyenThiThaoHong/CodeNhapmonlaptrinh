#include <iostream>
#include <cmath>
using namespace std;
int main()
{
	int n, k;
	cout << "Nhap n = ";
	cin >> n;
	cout << "Nhap k = ";
	cin >> k;
	float S = 0;
	int i = 1;
	while (i <= n)
	{
		S = S + pow(i, k);
		i = i + 1;
	}
	cout << "S = " << S;
	return 0;
}