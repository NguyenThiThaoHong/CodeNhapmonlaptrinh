#include <iostream>
#include <cmath>
using namespace std;
int main()
{
	float n;
	cout << "nhap n= ";
	cin >> n;
	int at = -2;
	float T = 3, D = 7;
	int ahh = 0, i = 2;
	while (i <= n)
	{
		T = T * 3;
		D = D * 7;
		ahh = 5 * at + 2 * T - 6 * D + 12;
		i = i + 1;
		at = ahh;
	}
	cout << "so hang thu n " << ahh;
	return 1;
}