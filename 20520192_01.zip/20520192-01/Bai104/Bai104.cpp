#include <iostream>
#include <cmath>
using namespace std;
int main()
{
	long S = 0;
	int i = 1;
	float e = 1;
	while (e >= pow(10, -6))
	{
		e = (float)1 / i * (i + 1);
		S = S + e;
		i = i + 1;
	}
	cout << "Tong S = " << S;
	return 0;
}