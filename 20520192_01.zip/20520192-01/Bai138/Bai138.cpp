#include <iostream>
#include <cmath>
using namespace std;
int main()
{
	float x;
	cout << "Nhap x = ";
	cin >> x;
	float S;
	if (x >= 0)
	{
		if (x <= 1)
			S = 5*x - 7;
		else
			S = 2 * pow(x,3) + 5 *pow (x ,2 )- 8 * x + 3;
	}
	else
		S = -2 * pow(x , 3) + 6 * x + 9;
	cout << "f(x) = " <<S;
	return 0;
}