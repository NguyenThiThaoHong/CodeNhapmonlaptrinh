#include <iostream>
#include <cmath>
using namespace std;
int main()
{
	int n;
	cout << "Nhap n = ";
	cin >> n;
	int T = 2;
	int att = -1;
	int at = 3;
	int i = 2;
	int ahh;
	while (i <= n)
	{
		T = T * 2;
		ahh = 5 * T + 5 * at - att;
		i = i + 1;
		att = at;
		at = ahh;
	}
	cout << "So hang thu " << n << " = " << ahh;
	return 0;
}