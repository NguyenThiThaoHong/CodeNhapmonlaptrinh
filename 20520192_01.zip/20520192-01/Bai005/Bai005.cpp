#include <iostream>
#include <cmath>
using namespace std;
int main()
{
	float r;
	cout << "Nhap ban kinh = ";
	cin >> r;
	float V = (float)4 / 3 * 3.14 * pow(r, 3);
	cout << "The tich = " << V;
	return 0;
}