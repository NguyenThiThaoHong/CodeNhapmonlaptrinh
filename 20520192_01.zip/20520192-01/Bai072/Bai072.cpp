#include <iostream>
#include <cmath>
using namespace std;
int main()
{
	int n;
	cout << "Nhap n = ";
	cin >> n;
	float S = 0;
	int M = 0;
	int i = 1;
	while (i <= n)
	{
		M += i;
		S += (float)1 / M;;
		i += 1;
	}
	cout << "Tong S = " << S;
	return 0;
}