#include <iostream>
#include <cmath>
using namespace std;
int main()
{
	int n;
	cout << "Nhap so nguyen duong n = ";
	cin >> n;
	int S = 0;
	int i = 1;
	while (i < n)
	{
		if (n % i == 0)
			S += i;
		i += 1;
	}
	cout << "Tong cac uoc so nho hon " << n << " la S = " << S;
	return 0;
}