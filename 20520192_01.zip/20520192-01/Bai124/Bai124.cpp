#include <iostream>
#include <cmath>
using namespace std;
int main()
{
	int n;
	cout << "Nhap n = ";
	cin >> n;
	int at = 2, bt = 1, i = 2, ahh, bhh;
	while (i <= n)
	{
		ahh = pow(at, 2) + 2 * pow(bt, 2);
		bhh = 2 * at * bt;
		i = i + 1;
		at = ahh;
		bt = bhh;
	}
	cout << ahh << " " << bhh;
	return 0;
}