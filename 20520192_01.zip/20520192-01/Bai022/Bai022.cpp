#include <iostream>
#include <cmath>
using namespace std;
int main()
{
	int n;
	cout << "Nhap so nguyen duong n = ";
	cin >> n;
	int dv = n % 10;
	cout << "Chu so hang don vi = " << dv;
	return 0;
}