#include <iostream>
#include <cmath>
using namespace std;
int main()
{
	int n;
	cout << "Nhap n = ";
	cin >> n;
	int t = n;
	int d = 0;
	while (t != 0)
	{
		d++;
		t = t / 10;
	}
	cout << "xuat d :" << d;
	return 0;
}