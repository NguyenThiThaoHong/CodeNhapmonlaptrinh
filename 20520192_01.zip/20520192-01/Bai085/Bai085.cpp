#include <iostream>
#include <cmath>
using namespace std;
int main()
{
	float x;
	cout << "Nhap x = ";
	cin >> x;
	int n;
	cout << "Nhap n = ";
	cin >> n;
	float S = 0;
	float T = 1;
	int i = 1;
	int dau = 1;
	while (i <= n)
	{
		T = T * x;
		S = S + dau * T;
		i = i + 1;
		dau = -dau;
	}
	cout << "Tong S = " << S;
	return 0;
}