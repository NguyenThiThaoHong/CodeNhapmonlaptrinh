 #include <iostream>
#include <cmath>
using namespace std;
int main()
{
	int n;
	cout << "Nhap n = ";
	cin >> n;
	int dem = 0, m = 1, t = abs(n);
	while (t > 0)
	{
		m = t;
		t = t / 10;
	}
	int k = abs(n);
	while (k != 0)
	{
		int dv1 = k % 10;
		if (dv1 == m)
			dem++;
		k = k / 10;
	}
	cout << "So luong chu so dau tien cua " << n << " la " << dem;
	return 0;
}