#include <iostream>
#include <cmath>
using namespace std;
int main()
{
	int n;
	cout << "Nhap n = ";
	cin >> n;
	long S = 0;
	long T = 1;
	int i = 1;
	while (i <= n)
	{
		T *= i;
		S += T;
		i += 1;
	}
	cout << "Tong S = " << S;
	return 0;
}