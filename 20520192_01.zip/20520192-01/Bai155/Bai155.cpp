#include <iostream>
#include <cmath>
using namespace std;
int main()
{
	int n;
	cout << "Nhap n = ";
	cin >> n;
	int a = 1;
	int i = 0;
	while (i <= n)
	{
		a = a * 2;
		cout << a << " ";
		i = i + 1;
	}
	return 0;
}