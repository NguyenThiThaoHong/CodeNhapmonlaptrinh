#include <iostream>
#include <cmath>
using namespace std;
int main()
{
	int n;
	cout << "Nhap n = ";
	cin >> n;
	if (n % 400 == 0 || (n % 4 == 0 && n % 100 != 0))
		cout << "nam nhuan";
	else
		cout << "ko phai nam nhuan";
	return 1;
}




	