#include <iostream>
#include <cmath>
using namespace std;
int main()
{
	int n;
	cout << "Nhap so nguyen duong n = ";
	cin >> n;
	int S = 0;
	int t = n;
	while (t != 0)
	{
		int dv = t % 10;
		if (dv % 2 == 0)
		{
			S += dv;
		}
		t = t / 10;
	}
	cout << "Tong cac chu so chan cua " << n << " la S = " << S;
	return 0;
}