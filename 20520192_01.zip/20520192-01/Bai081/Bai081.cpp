#include <iostream>
#include <cmath>
using namespace std;
int main()
{
	float x;
	cout << "Nhap x = ";
	cin >> x;
	int n;
	cout << "Nhap n = ";
	cin >> n;
	float S = (float)1 / x;
	float M = x;
	int i = 1;
	while (i <= n)
	{
		M *= (x + i);
		S += (float)1 / M;
		i += 1;
	}
	cout << "Tong S = " << S;
	return 0;
}