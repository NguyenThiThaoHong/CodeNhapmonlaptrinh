#include <iostream>
#include <cmath>
using namespace std;
int main()
{
	int x, y;
	cout << "Nhap nam bat dau : ";
	cin >> x;
	cout << "Nhap nam ket thuc : ";
	cin >> y;
	int i = x;
	cout << "Cac nam co nam nhuan tu nam " << x << " den nam " << y << " la: ";
	while (i <= y)
	{
		int dk1 = (i % 4 == 0 && i % 100 != 0);
		int dk2 = (i % 400 == 0);
		if (dk1 || dk2)
			cout << i << " ";
		i = i + 1;
	}
	return 0;
}