#include <iostream>
#include <cmath>
using namespace std;
int main()
{
	float C;
	cout << "Nhap nhiet do theo C = ";
	cin >> C;
	float F = (float)9 / 5 * C + 32;
	cout << "Nhiet do theo F = " << F;
	return 0;
}