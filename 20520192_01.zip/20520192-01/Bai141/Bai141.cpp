#include <iostream>
#include <cmath>
using namespace std;
int main()
{
	int n;
	cout << "Nhap so nguyen duong n = ";
	cin >> n;
	int dt = abs(n);
	while (dt >= 10)
		dt = dt / 10;
	cout << "Chu so dau tien la: " << dt;
	return 0;
}
