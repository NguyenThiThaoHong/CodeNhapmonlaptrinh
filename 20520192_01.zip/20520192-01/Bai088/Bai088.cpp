#include <iostream>
#include <cmath>
using namespace std;
int main()
{
	int n;
	cout << "Nhap n = ";
	cin >> n;
	float S = 0;
	float T = 0;
	int i = 1, dau = 1;
	while (i <= n)
	{
		T += i;
		S = S + dau * (float)(1 / T);
		i = i + 1;
		dau = -dau;
	}
	cout << "Tong S = " << S;
	return 0;
}