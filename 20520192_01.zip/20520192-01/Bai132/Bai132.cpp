#include <iostream>
#include <cmath>
using namespace std;
float S(float a, float b, float c, float d, float e, float f)
{
	float i = a * d + c * f + e * b - a * f - c * b - e * d;
	float S = (float)1 / 2 * abs(i);
	return S;
}
int main()
{
	float xA, yA, xB, yB, xC, yC, xM, yM;
	cout << "Nhap xA = ";
	cin >> xA;
	cout << "Nhap yA = ";
	cin >> yA;
	cout << "Nhap xB = ";
	cin >> xB;
	cout << "Nhap yB = ";
	cin >> yB;
	cout << "Nhap xC = ";
	cin >> xC;
	cout << "Nhap yC = ";
	cin >> yC;
	cout << "Nhap xM = ";
	cin >> xM;
	cout << "Nhap yM = ";
	cin >> yM;
	float SABC = S(xA, yA, xB, yB, xC, yC);
	float SMAB = S(xM, yM, xA, yA, xB, yB);
	float SMBC = S(xM, yM, xB, yB, xC, yC);
	float SMCA = S(xM, yM, xC, yC, xA, yA);
	if (SABC == (SMAB + SMBC + SMCA))
		cout << "M thuoc tam giac";
	else
		cout << "M khong thuoc tam giac";
	return 0;
}