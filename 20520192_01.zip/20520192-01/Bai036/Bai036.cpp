#include <iostream>
using namespace std;
int main()
{
	float x;
	cout << "Nhap x = ";
	cin >> x;
	int n;
	cout << "Nhap n = ";
	cin >> n;
	float T = 1;
	int i = 1;
	while (i <= n)
	{
		T *= x;
		i += 1;
	}
	cout << "T = " << T;
	return 0;
}