#include <iostream>
#include <cmath>
using namespace std;
int main()
{
	int n;
	cout << "Nhap n = ";
	cin >> n;
	int dem = 0, lc = n % 10, t = n;
	while (t != 0)
	{
		int dv = t % 10;
		if (dv < lc)
			lc = dv;
		t = t / 10;
	}
	int k = n;
	while (k != 0)
	{
		int dv1 = k % 10;
		if (dv1 == lc)
			dem++;
		k = k / 10;
	}
	cout << "So luong chu so nho nhat cua " << n << " la " << dem;
	return 0;
}