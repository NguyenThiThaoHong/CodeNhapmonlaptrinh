#include <iostream>
#include <cmath>
using namespace std;
int main()
{
	int n;
	cout << "Nhap so nguyen duong n = ";
	cin >> n;
	int hc = (n / 10) % 10;
	cout << "Chu so hang chuc = " << hc;
	return 0;
}