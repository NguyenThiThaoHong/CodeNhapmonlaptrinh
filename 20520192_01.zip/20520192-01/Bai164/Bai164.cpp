#include <iostream>
#include <cmath>
using namespace std;
int main()
{
	int n;
	cout << "Nhap n = ";
	cin >> n;
	float S = 0;
	int i = 0;
	while (i <= n)
	{
		S = (float)1 / (1 + S);
		i = i + 1;
	}
	cout << "S = " << S;
	return 0;
}