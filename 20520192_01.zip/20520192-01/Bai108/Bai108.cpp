#include <iostream>
#include <cmath>
using namespace std;
int main()
{
	float x;
	cout << "nhap x= ";
	cin >> x;
	float S = 0, T = 1, e = 1;
	int M = 1, i = 1;
	while (e >= pow(10, -6))
	{
		T = T * x;
		M = M * i;
		e = T / M;
		S = S + e;
		i = i + 1;
	}
	cout << "e^x= " << S;
	return 1;
}