#include <iostream>
#include <cmath>
using namespace std;
int main()
{
	float x, y, z;
	cout << "Nhap x = ";
	cin >> x;
	cout << "Nhap y = ";
	cin >> y;
	cout << "Nhap z = ";
	cin >> z;
	if (x < y + z && y < x + z && z < x + y)
		cout << "La tam giac";
	else
		cout << "Khong la tam giac";
	return 0;
}
