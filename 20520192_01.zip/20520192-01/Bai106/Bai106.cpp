#include <iostream>
#include <cmath>
using namespace std;
int main()
{
	float x;
	cout << "nhap x= ";
	cin >> x;
	float S = x;
	float sinx = x;
	long T = x, M = 1;
	int i = 3;
	float dau = -1;
	float e = 1;
	while (e >= pow(10, -6))
	{
		T = T * x * x;
		M = M * i * (i + 1);
		e = (float)T / M;
		sinx = e + sinx;
		dau = -dau;
		i = i + 2;
	}
	cout << "Tong sin(x) = " << sin(x);
	return 0;
}