#include <iostream>
#include <cmath>
using namespace std;
int main()
{
	float x;
	cout << "Nhap x = ";
	cin >> x;
	int n;
	cout << "Nhap n = ";
	cin >> n;
	float S = x;
	float T = x;
	int i = 1, dau = -1;
	while (i <= n)
	{
		T *= pow(x, 2);
		S = S + dau * T;
		i = i + 1;
		dau = -dau;
	}
	cout << "Tong S = " << S;
	return 0;
}