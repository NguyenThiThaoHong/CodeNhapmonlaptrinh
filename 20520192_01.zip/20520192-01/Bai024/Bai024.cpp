#include <iostream>
#include <cmath>
using namespace std;
int main()
{
	int n;
	cout << "Nhap so nguyen duong n = ";
	cin >> n;
	int ht = (n % 1000) / 100;
	cout << "Chu so hang tram = " << ht;
	return 0;
}