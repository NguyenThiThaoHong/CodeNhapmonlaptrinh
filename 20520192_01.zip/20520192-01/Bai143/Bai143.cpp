#include <iostream>
#include <cmath>
using namespace std;
int main()
{
	int n;
	cout << "Nhap so nguyen duong n = ";
	cin >> n;
	int S = 0, i = 1;
	while (i < n)
	{
		if (n % i == 0)
			S = S + i;
		i = i + 1;
	}
	if (S == n)
		cout << "Day la so hoan thien";
	else
		cout << "Khong phai so hoan thien";
	return 0;
}