#include <iostream>
#include <cmath>
using namespace std;
int main()
{
	int n;
	cout << "Nhap n = ";
	cin >> n;
	int ftt = 1;
	int ft = 1;
	int i = 2;
	int fhh;
	while (i <= n)
	{
		fhh = ft + ftt;
		i = i + 1;
		ftt = ft;
		ft = fhh;
	}
	cout << "So hang thu " << n << " = " << fhh;
	return 0;
}