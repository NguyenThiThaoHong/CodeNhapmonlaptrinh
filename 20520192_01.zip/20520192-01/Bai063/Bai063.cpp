#include <iostream>
#include <cmath>
using namespace std;
int main()
{
	int n;
	cout << "Nhap n = ";
	cin >> n;
	int Dem = 0;
	int t = n;
	int dv = 0;
	while (t != 0)
	{
		dv = t % 10;
		if (dv % 2 != 0)
			Dem += 1;
		t = t / 10;
	}
	cout << "so luong chu so le  :" << Dem;
	return 0;
}