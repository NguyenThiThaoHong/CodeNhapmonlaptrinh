#include <iostream>
#include <cmath>
using namespace std;
int main()
{
	int n;
	cout << "Nhap n = ";
	cin >> n;
	int flag = 1, t = n;
	while (t != 0)
	{
		int dv = t % 10;
		int m = (t % 100) / 10;
		if (m < dv && m != 0)
			flag = 0;
		t = t / 10;
	}
	if (flag == 1)
		cout << "Giam dan";
	else
		cout << "Khong giam dan";
	return 0;
}