﻿#include <iostream>
#include <cmath>
using namespace std;
int main()
{
	int n;
	cout << "Nhap n = ";
	cin >> n;
	int i = 1;
	int dem = 0;
	while (i <= n)
	{
		if (n % i == 0)
			dem += 1;
		i += 1;
	}
	cout << "so uoc của so nguyen n " << dem;
	return 0;
}