#include <iostream>
#include <cmath>
using namespace std;
int main()
{
	int n;
	cout << "Nhap so nguyen duong n = ";
	cin >> n;
	int T = 1;
	int i = 1;
	while (i <= n)
	{
		if (n % i == 0)
			T = T * i;
		i += 1;
	}
	cout << "Tich cac uoc so T = " << T;
	return 0;
}