#include <iostream>
#include <cmath>
using namespace std;
int main()
{
	int n;
	cout << "Nhap n = ";
	cin >> n;
	int t = n;
	int flag = 0;
	int dv = 0;
	while (t != 0)
	{
		dv = t % 10;
		if (dv % 2 != 0)
			flag = 1;
		t = t / 10;
	}
	if (flag == 1)
		cout << "TT";
	else
		cout << "ko TT";
	return 0;
}