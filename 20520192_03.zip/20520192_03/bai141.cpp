#include <cstdlib>
#include <iostream>
#include <ctime>
#include <iomanip>
using namespace std;

void Nhap(int[], int&);
void Xuat(int[], int);
void HoanVi(int&, int&);
bool ktHoanThien(int);
void HoanThienGiam(int[], int);

int main()
{
	int a[100];
	int n;
	Nhap(a, n);

	cout << "\nMang ban dau:";
	Xuat(a, n);

	cout << "\nCac so hoan thien giam: ";
	HoanThienGiam(a, n);
	XUat(a, n);
	return 1;
}

void Nhap(int a[], int& n)
{
	cout << "Nhap n: ";
	cin >> n;
	srand(time(nullptr));
	for (int i = 0; i < n; i++)
		a[i] = -100.0 + (rand() / (RAND_MAX / (200.0)));
}
void Xuat(int a[], int n)
{
	for (int i = 0; i < n; ++i)
	{
		cout << setw(6) << a[i];
	}
}
void HoanVi(int& c, int& d)
{
	int luu = c;
	c = d;
	d = luu;
}
bool ktHoanThien(int n)
{
	int s = 0;
	for (int i = 1; i < n; ++i)
	{
		if (n % i == 0)
			s += i;
	}
	if (s == n)
		return true;
	return false;
}
void HoanThienGiam(int a[], int n)
{
	for (int i = 0; i < n - 1; ++i)
	{
		for (int j = i + 1; j < n; ++j)
		{
			if (ktHoanThien(a[i]) && ktHoanThien(a[j]) && a[i] < a[j])
				HoanVi(a[i], a[j]);
		}

	}
}
