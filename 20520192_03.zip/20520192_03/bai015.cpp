// 000int.cpp : This file contains the 'main' function. Program execution begins and ends there.
#include <cstdlib>
#include <iostream>
#include <ctime>
#include <iomanip>
using namespace std;

void Nhap(float[],int &, float &,float &);
void Xuat(float[],int, float,float);
void LietKe(float[], int,float ,float);

int main()
{
	float b[100];
	float x,y;
	int n;
	Nhap(b,n, x,y);
	cout << "\n mang ban dau";
	Xuat(b,n, x,y);
	LietKe(b,n,x,y );
	return 1;
}

void Nhap(float a[],int& n, float& x,float &y)
{
	cout << "Nhap n: ";
	cin >> n;
	cout << "Nhap x: ";
	cin >> x;
	cout << "Nhap y: ";
	cin >> y;
	srand(time(nullptr));
	for (int i = 0; i < n; i++)
		a[i] = -100 + rand() / (RAND_MAX / 200.0);
}

void Xuat(float a[], int n,float x,float y)
{
	for (int i = 0; i < n; i++)
	{
		cout << setw(6) << setprecision(3) << a[i];
	}
}
void LietKe(float a[], int n,float x,float y)
{
	cout << "\n cac gia tri trong doan x,y";
	for (int i = 0; i <= n - 1; i++)
		if (a[i] >=x && a[i]<=y)
			cout << setw(6) << a[i];
}