#include <cstdlib>
#include <iostream>
#include <ctime>
#include <iomanip>
using namespace std;

void Nhap(float[], int&);
void Xuat(float[], int);
void NguyenHoa(float[], int);

int main()
{
	float a[100];
	int n;

	Nhap(a, n);

	cout << "\nTruoc Khi nguyen hoa: ";
	Xuat(a, n);

	NguyenHoa(a, n);
	cout << "\nSau khi nguyen hoa: ";
	Xuat(a, n);
	return 1;
}

void Nhap(float a[], int& n)
{
	cout << "Nhap n: ";
	cin >> n;
	srand(time(nullptr));
	for (int i = 0; i < n; i++)
		a[i] = -100.0 + (rand() / (RAND_MAX / (200.0)));
}
void Xuat(float a[], int n)
{
	for (int i = 0; i < n; i++)
	{
		cout << setw(6) << setprecision(3) << a[i];
	}
}
void NguyenHoa(float a[], int n)
{
	for (int i = 0; i < n; i++)
	{
		if (a[i] > 0)
			a[i] = (int)(a[i] + 0.5);
		else
			a[i] = (int)(a[i] - 0.5);
	}
}
