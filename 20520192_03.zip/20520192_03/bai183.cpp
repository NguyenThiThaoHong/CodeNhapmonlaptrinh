#include <cstdlib>
#include <iostream>
#include <ctime>
#include <iomanip>
using namespace std;

void Nhap(float[], int&);
void Xuat(float[], int);
int ktCon(float[], int, float[], int);

int main()
{
	float b[100], c[100];
	int k, m;
	cout << "Nhap so luong phan tu trong mang a: ";
	Nhap(b, k);
	cout << "Mang a la: ";
	Xuat(b, k);

	cout << endl;

	cout << "Nhap so luong phan tu trong mang b: ";
	Nhap(c, m);
	cout << "Mang b la: ";
	Xuat(c, m);

	int kt = ktCon(b, k, c, m);
	if (kt == 1)
		cout << "\nMang a la mang con trong mang b";
	else
		cout << "\nMang a khong la mang con trong mang b";

	return 1;
}

void Nhap(float a[], int& n)
{
	cin >> n;
	srand(time(nullptr));
	for (int i = 0; i < n; i++)
		a[i] = -100 + rand() / (RAND_MAX / 200.0);
}

void Xuat(float a[], int n)
{
	for (int i = 0; i < n; i++)
	{
		cout << setw(6) << setprecision(3) << a[i];
	}
}

int ktCon(float a[], int n, float b[], int m)
{
	if (n > m)
		return 0;
	int flag = 0;
	for (int vt = 0; vt <= m - n; vt++)
	{
		int co = 1;
		for (int i = 0; i < n; i++)
			if (a[i] != b[vt + i])
				co = 0;
		if (co == 1)
			flag = 1;
	}
	return flag;
}

