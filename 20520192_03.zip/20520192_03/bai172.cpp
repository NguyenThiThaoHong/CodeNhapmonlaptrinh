#include <cstdlib>
#include <iostream>
#include <ctime>
#include <iomanip>
using namespace std;

void NhapTang(float[], int&);
void Xuat(float[], int);

int main()
{
	float b[100];
	int n;
	NhapTang(b, n);
	cout << "\nMang sau khi nhap la: ";
	Xuat(b, n);

	return 1;
}

void NhapTang(float a[], int& n)
{
	cout << "Nhap n: ";
	cin >> n;
	for (int i = 0; i < n; i++)
	{
		float x;
		cout << "Nhap a[" << i << "]: ";
		cin >> x;
		int j;
		for (j = i - 1; j >= 0 && a[j] > x; j--)
			a[j + 1] = a[j];
		a[j + 1] = x;
	}
}
void Xuat(float a[], int n)
{
	for (int i = 0; i < n; i++)
	{
		cout << setw(6) << setprecision(3) << a[i];
	}
}


