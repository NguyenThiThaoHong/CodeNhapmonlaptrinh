#include <cstdlib>
#include <iostream>
#include <ctime>
#include <iomanip>
using namespace std;

void Nhap(int[], int&);
void Xuat(int[], int);
void HoanVi(int&, int&);
void ChanTang(int[], int);
void LeTang(int[], int);
void ChanTangLeTang(int[], int);

int main()
{
	int a[100];
	int n;

	Nhap(a, n);

	cout << "\nMang ban dau la: ";
	Xuat(a, n);

	cout << "\nCac so chan, le tang: ";
	ChanTangLeTang(a, n);
	Xuat(a, n);
	return 1;
}

void Nhap(int a[], int& n)
{
	cout << "Nhap n: ";
	cin >> n;
	srand(time(nullptr));
	for (int i = 0; i < n; ++i)
		a[i] = rand() % (200 + 1) - 100;
}
void Xuat(int a[], int n)
{
	for (int i = 0; i < n; ++i)
	{
		cout << setw(6) << a[i];
	}
}
void HoanVi(int& c, int& d)
{
	int luu = c;
	c = d;
	d = luu;
}
void ChanTang(int a[], int n)
{
	for (int i = 0; i < n - 1; ++i)
	{
		for (int j = i + 1; j < n; ++j)
			if (a[i] % 2 == 0 && a[j] % 2 == 0 && a[i] > a[j])
				HoanVi(a[i], a[j]);
	}
}
void LeTang(int a[], int n)
{
	for (int i = 0; i < n - 1; ++i)
	{
		for (int j = i + 1; j < n; ++j)
			if (a[i] % 2 != 0 && a[j] % 2 != 0 && a[i] > a[j])
				HoanVi(a[i], a[j]);
	}
}
void ChanTangLeTang(int a[], int n)
{
	ChanTang(a, n);
	LeTang(a, n);
}
