#include <cstdlib>
#include <iostream>
#include <ctime>
#include <iomanip>
using namespace std;

void Nhap(float[], int&, float[], int&);
void Xuat(float[], int, float[], int);
void HoanVi(float&, float&);
void SapTang(float[], int);
int ktHoanVi(float[], int, float[], int);

int main()
{
	float a[100];
	int n;
	float b[100];
	int m;
	Nhap(a, n, b, m);

	Xuat(a, n, b, m);

	int kq = ktHoanVi(a, n, b, m);
	if (kq == 1)
		cout << "\nb la hoan vi mang a ";
	else
		cout << "\nb ko la hoan vi mang a";
	return 1;
}

void Nhap(float a[], int& n, float b[], int& m)
{
	cout << "Nhap n: ";
	cin >> n;
	srand(time(nullptr));
	for (int i = 0; i < n; i++)
		a[i] = -100.0 + (rand() / (RAND_MAX / (200.0)));

	cout << "Nhap m: ";
	cin >> m;
	srand(time(nullptr));
	for (int i = 0; i < m; i++)
		b[i] = -100.0 + (rand() / (RAND_MAX / (200.0)));
}
void Xuat(float a[], int n, float b[], int m)
{
	cout << "\nMang ban dau cua a: ";
	for (int i = 0; i < n; i++)
	{
		cout << setw(6) << setprecision(3) << a[i];
	}
	cout << "\nMang ban dau cua b: ";
	for (int i = 0; i < m; i++)
	{
		cout << setw(6) << setprecision(3) << b[i];
	}
}
void HoanVi(float& c, float& d)
{
	float luu = c;
	c = d;
	d = luu;
}
void SapTang(float a[], int n)
{
	for (int i = 0; i < n - 1; ++i)
	{
		for (int j = i + 1; j < n; ++j)
		{
			if (a[i] > a[j])
				HoanVi(a[i], a[j]);
		}
	}
}
int ktHoanVi(float a[], int n, float b[], int m)
{
	if (m != n)
		return 0;
	SapTang(a, n);
	SapTang(b, m);
	int flag = 1;
	for (int i = 0; i < n; ++i)
		if (a[i] != b[i])
			flag = 0;
	return flag;
}
