#include <cstdlib>
#include <iostream>
#include <ctime>
#include <iomanip>
using namespace std;

void Nhap(float[], int&);
void Xuat(float[], int);
void XoaViTri(float[], int&, int);
void XoaTrungX(float[], int&, float);

int main()
{
	float b[100];
	int n;
	Nhap(b, n);
	cout << "\nMang ban dau:";
	Xuat(b, n);
	float x;
	cout << "\nNhap x: ";
	cin >> x;
	cout << "\nMang sau khi xoa cac gia tri trung voi " << x << " la: ";
	XoaTrungX(b, n, x);
	for (int i = 0; i < n; i++)
		cout << setw(6) << setprecision(3) << b[i];

	return 1;
}

void Nhap(float a[], int& n)
{
	cout << "Nhap n: ";
	cin >> n;
	srand(time(nullptr));
	for (int i = 0; i < n; i++)
		a[i] = -100.0 + (rand() / (RAND_MAX / (200.0)));
}
void Xuat(float a[], int n)
{
	for (int i = 0; i < n; i++)
	{
		a[i] = (float)((int)a[i] * 100) / 100;
		cout << setw(6) << setprecision(3) << a[i];
	}
}
void XoaViTri(float a[], int& n, int k)
{
	for (int i = k; i < n - 1; i++)
		a[i] = a[i + 1];
	n--;
}
void XoaTrungX(float a[], int& n, float x)
{
	for (int i = n - 1; i >= 0; i--)
		if (a[i] == x)
			XoaViTri(a, n, i);
}
