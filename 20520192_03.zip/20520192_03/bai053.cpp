#include <cstdlib>
#include <iostream>
#include <ctime>
#include <iomanip>
using namespace std;

void Nhap(float [], int&,float &);
void Xuat(float[], int,float);
int TanSuat(float[], int,float);

int main()
{
	float b[100];
	int k;
	float x;
	Nhap(b, k,x);
	cout << "\n mang ban dau";
	Xuat(b, k,x);
	cout << "\n so lan xuat hien cua gia tri x la " << TanSuat(b, k,x);
	return 1;
}

void Nhap(float a[], int& n, float& x)
{
	cout << "Nhap n: ";
	cin >> n;
	srand(time(nullptr));
	for (int i = 0; i < n; i++)
		a[i] = rand() % (200 + 1) - 100;
	cout << "Nhap x: ";
	cin >> x;

}
void Xuat(float a[], int n,float x)
{
	for (int i = 0; i < n; i++)
	{
		cout << setw(6) << a[i];
	}
}
int TanSuat(float a[], int n,float x)
{
	int dem = 0;
	for (int i = 0; i < n; i++)
		if (a[i] == x)
			dem++;
	return dem;
}

int ktThuoc(int[], int, int[], int)
{
	return 0;
}
