#include <cstdlib>
#include <iostream>
#include <ctime>
#include <iomanip>
using namespace std;

void Nhap(float[], int&);
void Xuat(float[], int);
void ThemViTri(float[], int&, float, int);

int main()
{
	float b[100];
	int n;
	Nhap(b, n);
	cout << "\nMang ban dau:";
	Xuat(b, n);
	float x;
	cout << "\nNhap x: ";
	cin >> x;
	int k;
	cout << "Nhap vi tri k: ";
	cin >> k;
	cout << "\nMang sau khi them " << x << " tai vi tri thu " << k << " la: ";
	ThemViTri(b, n, x, k);
	for (int i = 0; i < n; i++)
		cout << setw(6) << setprecision(3) << b[i];

	return 1;
}

void Nhap(float a[], int& n)
{
	cout << "Nhap n: ";
	cin >> n;
	srand(time(nullptr));
	for (int i = 0; i < n; i++)
		a[i] = -100.0 + (rand() / (RAND_MAX / (200.0)));
}
void Xuat(float a[], int n)
{
	for (int i = 0; i < n; i++)
	{
		cout << setw(6) << setprecision(3) << a[i];
	}
}
void ThemViTri(float a[], int& n, float x, int k)
{
	for (int i = n; i >= k + 1; i--)
		a[i] = a[i - 1];
	a[k] = x;
	n++;
}
