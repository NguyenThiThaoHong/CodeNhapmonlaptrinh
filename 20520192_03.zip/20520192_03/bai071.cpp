// 000int.cpp : This file contains the 'main' function. Program execution begins and ends there.
#include <cstdlib>
#include <iostream>
#include <ctime>
#include <iomanip>
using namespace std;

void Nhap(float[], int&);
void Xuat(float[], int);
int DemXuatHien(float[], int, float[],int);
int main()
{
	float a[100], b[100];
	int k, l;
	Nhap(a, l);
	cout << "\n mang a ban dau ";
	Xuat(a, l);
	Nhap(b, k);
	cout << "\n mang b ban dau";
	Xuat(b, k);
	cout << "\n so lan xuat hien mang a trong b la: " << DemXuatHien(a, l, b, k);
	return 1;
}

void Nhap(float a[], int& n)
{
	cout << "\n Nhap n: ";
	cin >> n;
	srand(time(nullptr));
	for (int i = 0; i < n; i++)
		a[i] = -100 + rand() / (RAND_MAX / 200.0);
}

void Xuat(float a[], int n)
{
	for (int i = 0; i < n; i++)
	{
		cout << setw(6) << setprecision(3) << a[i];
	}
}
int DemXuatHien(float a[], int n, float b[], int m)
{
	if (n > m)
		return 0;
	int dem = 0;
	for (int vt = 0; vt <= m - n; vt++)
	{
		int flag = 1;
		for (int i = 0; i < n; i++)
			if (a[i] != b[vt + i])
				flag = 0;
		if (flag == 1)
			dem++;

	}
	return dem;
}
