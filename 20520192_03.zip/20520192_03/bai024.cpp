#include <cstdlib>
#include <iostream>
#include <ctime>
#include <iomanip>
using namespace std;

void Nhap(float[], int&);
void Xuat(float[], int);
float LonNhat(float[], int);
void LietKe(float[], int);

int main()
{
	float b[100];
	int k;
	Nhap(b, k);
	cout << "\n Ham ban dau la: ";
	Xuat(b, k);
	LietKe(b, k);
	return 1;
}

void Nhap(float a[], int& n)
{
	cout << "Nhap n: ";
	cin >> n;
	srand(time(nullptr));
	for (int i = 0; i < n; i++)
		a[i] = -100 + rand() / (RAND_MAX / 200.0);
}

void Xuat(float a[], int n)
{
	for (int i = 0; i < n; i++)
	{
		cout << setw(6) << setprecision(3) << a[i];
	}
}

void LietKe(float a[], int n)
{
	cout << "\n cac gia tritrong mang co it nhat 1 lan can trai dau voi no ";
	if (n == 1)
		return;
	if (a[0] * a[1] < 0)
		cout << setw(7) << a[0];
	for (int i = 1; i <= n - 2; i++)
		if (a[i] *(a[i + 1]) <0 || a[i]*a[i-1]<0)
			cout << setw(6) << a[i];
	if (a[n - 1] * a[n - 2] < 0)
		cout << setw(7) << a[n - 1];
}