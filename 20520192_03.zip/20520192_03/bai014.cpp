// 000int.cpp : This file contains the 'main' function. Program execution begins and ends there.
#include <cstdlib>
#include <iostream>
#include <ctime>
#include <iomanip>
using namespace std;

void Nhap(float[], int&);
void Xuat(float[], int);
void LietKe(float[], int);
bool kChinhPhuong(int);

int main()
{
	float b[100];
	int k;
	Nhap(b, k);
	cout << "\n mang ban dau";
	Xuat(b, k);
	LietKe(b, k);
	return 1;
}

void Nhap(float a[], int& n)
{
	cout << "Nhap n: ";
	cin >> n;
	srand(time(nullptr));
	for (int i = 0; i < n; i++)
		a[i] = -100 + rand() / (RAND_MAX / 200.0);
}

void Xuat(float a[], int n)
{
	for (int i = 0; i < n; i++)
	{
		cout << setw(6) << setprecision(3) << a[i];
	}
}
void LietKe(float a[], int n)
{
	cout << "\n vi tri cac gia tri so chinh phuong";
	for (int i = 0; i <= n - 1; i++)
		if (ktChinhPhuong(a[i]))
			cout << setw(6) << i;
}
bool ktChinhPhuong(int n)
{
	for (int i = 1; i <= n; i++)
		if (i* i == n)
			return true;
	return false;
}
