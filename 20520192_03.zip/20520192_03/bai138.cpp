// 000int.cpp : This file contains the 'main' function. Program execution begins and ends there.
#include <cstdlib>
#include <iostream>
#include <ctime>
#include <iomanip>
using namespace std;

void Nhap(float[], int&);
void Xuat(float[], int);
void HoanVi(float&, float&);
void SapGiam (float[], int);

int main()
{
	float b[100];
	int k;
	Nhap(b, k);
	cout << "\n Mang ban dau ";
	Xuat(b, k);

	SapGiam(b, k);
	cout << "\n Mang sau khi sap giam : ";
	Xuat(b, k);
	return 1;
}

void Nhap(float a[], int& n)
{
	cout << "Nhap n: ";
	cin >> n;
	srand(time(nullptr));
	for (int i = 0; i < n; i++)
		a[i] = -100 + rand() / (RAND_MAX / 200.0);
}

void Xuat(float a[], int n)
{
	for (int i = 0; i < n; i++)
	{
		cout << setw(6) << setprecision(3) << a[i];
	}
}

void HoanVi(float& a, float& b)
{
	float temp = a;
	a = b;
	b = temp;

}

void SapGiam(float a[], int n)
{
	for (int i = 0; i <= n - 2; i++)
		for (int j = i + 1; j <= n - 1; j++)
			if (a[i] < a[j])
				HoanVi(a[i], a[j]);
}
