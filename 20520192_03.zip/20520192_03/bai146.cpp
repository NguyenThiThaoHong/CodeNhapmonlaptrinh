#include <cstdlib>
#include <iostream>
#include <ctime>
#include <iomanip>
using namespace std;

void Nhap(int[], int&, int[], int&);
void Xuat(int[], int, int[], int);
void HoanVi(int&, int&);
void TangDan(int[], int, int[], int);
void Tron(int[], int, int[], int, int[], int&);
void XuatC(int[], int&);

int main()
{
	int a[100];
	int n;
	int b[100];
	int m;
	int c[100];
	int p;
	Nhap(a, n, b, m);

	TangDan(a, n, b, m);
	Xuat(a, n, b, m);

	Tron(a, n, b, m, c, p);
	cout << "\nTron a va b ta duoc: ";
	XuatC(c, p);
	return 1;
}
void Nhap(int a[], int& n, int b[], int& m)
{
	cout << "Nhap n: ";
	cin >> n;
	srand(time(nullptr));
	for (int i = 0; i < n; i++)
		a[i] = rand() % (200 + 1) - 100;

	cout << "Nhap m: ";
	cin >> m;
	srand(time(nullptr));
	for (int i = 0; i < m; i++)
		b[i] = rand() % (200 + 1) - 100;
}
void Xuat(int a[], int n, int b[], int m)
{
	cout << "\nMang cua a: ";
	for (int i = 0; i < n; i++)
	{
		cout << setw(6) << a[i];
	}
	cout << "\nMang cua b: ";
	for (int i = 0; i < m; i++)
	{
		cout << setw(6) << b[i];
	}
}
void HoanVi(int& c, int& d)
{
	int luu = c;
	c = d;
	d = luu;
}
void TangDan(int a[], int n, int b[], int m)
{
	for (int i = 0; i < n - 1; i++)
	{
		for (int j = i + 1; j < n; j++)
		{
			if (a[i] > a[j])
				HoanVi(a[i], a[j]);
			if (b[i] > b[j])
				HoanVi(b[i], b[j]);
		}
	}
}
void Tron(int a[], int n, int b[], int m, int c[], int& p)
{
	int i = 0, j = 0;
	p = 0;
	while (!(i >= n && j >= m))
	{
		if ((i < n && j < m && a[i] < b[j]) || (j >= m))
			c[p++] = a[i++];
		else
			c[p++] = b[j++];
	}
}
void XuatC(int c[], int& p)
{
	for (int i = 0; i < p; i++)
		cout << setw(5) << c[i];
}
