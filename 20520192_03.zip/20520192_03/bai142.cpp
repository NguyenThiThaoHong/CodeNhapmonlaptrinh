#include <cstdlib>
#include <iostream>
#include <ctime>
#include <iomanip>
using namespace std;

void Nhap(float[], int&);
void Xuat(float[], int);
void HoanVi(float&, float&);
void DuongTang(float[], int);

int main()
{
	float a[100];
	int n;
	Nhap(a, n);

	cout << "\nMang ban dau:";
	Xuat(a, n);

	cout << "\nCac so duong tang: ";
	DuongTang(a, n);
	Xuat(a, n);
	return 1;
}

void Nhap(float a[], int& n)
{
	cout << "Nhap n: ";
	cin >> n;
	srand(time(nullptr));
	for (int i = 0; i < n; i++)
		a[i] = -100.0 + (rand() / (RAND_MAX / (200.0)));
}
void Xuat(float a[], int n)
{
	for (int i = 0; i < n; i++)
	{
		cout << setw(6) << setprecision(3) << a[i];
	}
}
void HoanVi(float& c, float& d)
{
	float luu = c;
	c = d;
	d = luu;
}
void DuongTang(float a[], int n)
{
	for (int i = 0; i < n - 1; ++i)
	{
		for (int j = i + 1; j < n; ++j)
		{
			if (a[i] > 0 && a[j] > 0 && a[i] > a[j])
				HoanVi(a[i], a[j]);
		}

	}
}

