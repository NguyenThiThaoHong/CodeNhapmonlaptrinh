// 000int.cpp : This file contains the 'main' function. Program execution begins and ends there.
#include <cstdlib>
#include <iostream>
#include <ctime>
#include <iomanip>
using namespace std;

void Nhap(int[], int&, int&, int&);
void Xuat(int[], int, int, int);
void LietKe(int[], int, int, int);

int main()
{
	int b[100];
	int x, y;
	int n;
	Nhap(b, n, x, y);
	cout << "\n mang ban dau";
	Xuat(b, n, x, y);
	LietKe(b, n, x, y);
	return 1;
}

void Nhap(int a[], int&n, int&x, int&y)
{
	cout << "Nhap n: ";
	cin >> n;
	cout << "Nhap x: ";
	cin >> x;
	cout << "Nhap y: ";
	cin >> y;
	srand(time(nullptr));
	for (int i = 0; i < n; i++)
		a[i] = -100 + rand() / (RAND_MAX / 200.0);
}

void Xuat(int a[], int n, int x, int y)
{
	for (int i = 0; i < n; i++)
	{
		cout << setw(6) << setprecision(3) << a[i];
	}
}
void LietKe(int a[], int n, int x, int y)
{
	cout << "\n cac gia tri trong doan x,y";
	for (int i = 0; i <= n - 1; i++)
		if (a[i] >= x && a[i] <= y)
			if (a[i]%2==0)
				cout << setw(6) << a[i];


}