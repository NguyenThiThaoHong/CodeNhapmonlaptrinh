// 000int.cpp : This file contains the 'main' function. Program execution begins and ends there.
#include <cstdlib>
#include <iostream>
#include <ctime>
#include <iomanip>
using namespace std;

void Nhap(float[], int&);
void Xuat(float[], int);
int TanSuat(float[], int, float);
int ktThuoc(float[], int, float[], int);

int main()
{
	float b[100];
	int k;
	Nhap(b, k);
	cout << "\n mang a ban dau " ;
	Xuat(b, k);
	float c[100];
	int t;
	Nhap(c, t);
	cout << "\n mang b ban dau ";
	Xuat(c,t);
	int kq = ktThuoc(b, k, c, t);
	if (kq == 1)
		cout << "\n cac phan tu mang a thuoc mang b ";
	else
		cout << "\n cac phan tu mang a khong thuoc mang b ";
	return 1;
}

void Nhap(float a[], int& n)
{
	cout << "\n Nhap gia tri: ";
	cin >> n;
	srand(time(nullptr));
	for (int i = 0; i < n; i++)
		a[i] = -100 + rand() / (RAND_MAX / 200.0);
}

void Xuat(float a[], int n)
{
	for (int i = 0; i < n; i++)
	{
		cout << setw(6) << setprecision(3) << a[i];
	}
}
int TanSuat(float a[], int n, float x)
{
	int dem = 0;
	for (int i= 0; i < n; i++)
		if (a[i] == x)
			dem++;
	return dem;
}
int ktThuoc(float a[], int n, float b[], int m)
{
	int flag = 1;
	for (int i = 0; i < n; i++)
		if (TanSuat(b, m, a[i]) == 0)
			flag = 0;
	return flag;
}