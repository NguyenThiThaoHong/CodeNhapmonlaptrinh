#include <cstdlib>
#include <iostream>
#include <ctime>
#include <iomanip>
using namespace std;

void Nhap(float[], int&);
void Xuat(float[], int);
void ThemBaoToan(float[], int&, float);

int main()
{
	float b[100];
	int n;
	Nhap(b, n);
	cout << "\nMang ban dau:";
	Xuat(b, n);
	float x;
	cout << "\nNhap x: ";
	cin >> x;
	cout << "\nMang sau khi them " << x << " la: ";
	ThemBaoToan(b, n, x);
	for (int i = 0; i < n; i++)
		cout << setw(6) << setprecision(3) << b[i];

	return 1;
}

void Nhap(float a[], int& n)
{
	cout << "Nhap n: ";
	cin >> n;
	srand(time(nullptr));
	for (int i = 0; i < n; i++)
		a[i] = -100.0 + (rand() / (RAND_MAX / (200.0)));
}
void Xuat(float a[], int n)
{
	for (int i = 0; i < n; i++)
	{
		for (int j = i + 1; j < n; j++)
			if (a[i] > a[j])
			{
				float hv = a[i];
				a[i] = a[j];
				a[j] = hv;
			}
		cout << setw(6) << setprecision(3) << a[i];
	}
}
void ThemBaoToan(float a[], int& n, float x)
{
	int i = n - 1;
	while (i >= 0 && a[i] > x)
	{
		a[i + 1] = a[i];
		i--;
	}
	a[i + 1] = x;
	n++;
}

