#include <cstdlib>
#include <iostream>
#include <ctime>
#include <iomanip>
using namespace std;

void Nhap(int[], int&);
void Xuat(int[], int);
int ktHoanThien(int);
int ktTinhChat(int[], int);

int main()
{
	int b[100];
	int k;
	Nhap(b, k);
	cout << "\n Ham ban dau la: ";
	Xuat(b, k);
	int kq = ktTinhChat(b, k);
	cout << endl << kq;
	return 1;
}

void Nhap(int a[], int& n)
{
	cout << "Nhap n: ";
	cin >> n;
	srand(time(nullptr));
	for (int i = 0; i < n; i++)
		a[i] = rand() % (200 + 1) - 100;
}
void Xuat(int a[], int n)
{
	for (int i = 0; i < n; i++)
	{
		cout << setw(6) << a[i];
	}
}
int ktHoanThien(int n)
{
	int s = 0;
	int flag = 0;
	for (int i = 1; i <= n - 1; i++)
		if (n % i == 0)
			s += i;
	if (s == n)
		flag = 1;
	else
		flag = 0;
	return flag;
}
int ktTinhChat(int a[], int n)
{
	int dem = 0;
	for (int i = 0; i < n; i++)
		if (ktHoanThien(a[i]) && a[i] > 256)
			dem++;
	if (dem == 0)
		return 1;
	return 0;
}
