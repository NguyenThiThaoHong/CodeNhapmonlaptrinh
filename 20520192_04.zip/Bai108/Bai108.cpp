#include <cstdlib>
#include <iostream>
#include <ctime>
#include <iomanip>
using namespace std;

void Nhap(float[][100], int&, int&);
void Xuat(float[][100], int, int);
int ktGiam(float[][100], int, int);
int ktHangGiam(float[][100], int, int, int);
int ktCotGiam(float[][100], int, int, int);

int main()
{
	float b[100][100];
	int k, l;

	Nhap(b, k, l);
	cout << "Ma tran ban dau: " << endl;
	Xuat(b, k, l);

	int flag = ktGiam(b, k, l);
	if (flag == 1)
		cout << "Ma tran giam dan theo dong va cot";
	else
		cout << "Ma tran khong giam dan theo dong va cot";
	return 0;
}

void Nhap(float a[][100], int& m, int& n)
{
	cout << "Nhap so dong: ";
	cin >> m;
	cout << "Nhap so cot: ";
	cin >> n;
	srand(time(nullptr));
	for (int i = 0; i < m; i++)
		for (int j = 0; j < n; j++)
			a[i][j] = -100 + rand() / (RAND_MAX / 200.0);
}

void Xuat(float a[][100], int m, int n)
{
	for (int i = 0; i < m; i++)
	{
		for (int j = 0; j < n; j++)
			cout << setw(10) << setprecision(3) << a[i][j];
		cout << endl;
	}
}

int ktHangGiam(float a[][100], int m, int n, int x)
{
	int flag = 1;
	for (int j = 0; j < n - 1; j++)
	{
		for (int k = j + 1; k < n; k++)
		{
			if (a[x][j] < a[x][k])
			{
				flag = 0;
				break;
			}
		}
	}
	return flag;
}
int ktCotGiam(float a[][100], int m, int n, int x)
{
	int flag = 1;
	for (int i = 0; i < m - 1; i++)
	{
		for (int k = i + 1; k < m; k++)
		{
			if (a[i][x] < a[i + 1][x])
			{
				flag = 0;
				break;
			}
		}
	}
	return flag;
}

int ktGiam(float a[][100], int m, int n)
{
	int flag = 1;
	for (int i = 0; i < m; i++)
	{
		for (int j = 0; j < n; j++)
		{
			if (ktHangGiam(a, m, n, i) == 0 || ktCotGiam(a, m, n, j) == 0)
			{
				flag = 0;
				break;
			}
		}
	}
	return flag;
}
