#include <iostream>
#include <cstdlib>
#include <ctime>
#include <iomanip>

#define MAX 100

using namespace std;

void Nhap(int[][MAX], int&, int&);
void Xuat(int[][MAX], int, int);
bool ktChinhPhuong(int);
int ChinhPhuongDau(int[][MAX], int, int);
int ChinhPhuongLonNhat(int[][MAX], int, int);

int main()
{
	int b[100][100];
	int k, l;

	Nhap(b, k, l);
	cout << "Mang tran ban dau: " << endl;
	Xuat(b, k, l);

	cout << "So chinh phuong lon nhat trong mang la: " << ChinhPhuongLonNhat(b, k, l);

	return 0;
}

void Nhap(int a[][100], int& m, int& n)
{
	cout << "Nhap so dong: ";
	cin >> m;
	cout << "Nhap so cot: ";
	cin >> n;

	srand(time(nullptr));

	for (int i = 0; i < m; i++)
		for (int j = 0; j < n; j++)
			a[i][j] = (rand() % 201) - 100;
}

void Xuat(int a[][100], int m, int n)
{
	for (int i = 0; i < m; i++)
	{
		for (int j = 0; j < n; j++)
			cout << setw(7) << a[i][j];
		cout << endl;
	}
}

bool ktChinhPhuong(int n)
{
	int flag = 0;
	for (int i = 0; i <= n; i++)
		if (i * i == n)
			flag = 1;
	return flag;
}


int ChinhPhuongDau(int a[][MAX], int m, int n)
{
	for (int i = 0; i < m; i++)
		for (int j = 0; j < n; j++)
			if (ktChinhPhuong(a[i][j]))
				return a[i][j];
	return 0;
}

int ChinhPhuongLonNhat(int a[][MAX], int m, int n)
{
	int ln = ChinhPhuongDau(a, m, n);
	for (int i = 0; i < m; i++)
		for (int j = 0; j < n; j++)
			if (ktChinhPhuong(a[i][j]) && a[i][j] > ln)
				ln = a[i][j];
	return ln;
}
