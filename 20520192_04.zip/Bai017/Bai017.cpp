#include <iostream>
#include <cstdlib>
#include <ctime>
#include <iomanip>

#define MAX 100

using namespace std;

void Nhap(int[][MAX], int&, int&);
void Xuat(int[][MAX], int, int);
bool ktHoanThien(int);
void LietKe(int[][MAX], int, int, int);

int main()
{
	int b[100][100];
	int k, l;

	Nhap(b, k, l);
	cout << "Mang tran ban dau: " << endl;
	Xuat(b, k, l);

	int row;
	cout << "Nhap dong can liet ke: ";
	cin >> row;

	LietKe(b, k, l, row);

	return 0;
}

void Nhap(int a[][100], int& m, int& n)
{
	cout << "Nhap so dong: ";
	cin >> m;
	cout << "Nhap so cot: ";
	cin >> n;

	srand(time(nullptr));

	for (int i = 0; i < m; i++)
	{
		for (int j = 0; j < n; j++)
			a[i][j] = rand() % 201 + 1;
	}
}

void Xuat(int a[][100], int m, int n)
{
	for (int i = 0; i < m; i++)
	{
		for (int j = 0; j < n; j++)
			cout << setw(6) << a[i][j];
		cout << endl;
	}
}

bool ktHoanThien(int n)
{
	int s = 0, i = 1;
	while (i < n)
	{
		if (n % i == 0)
			s = s + i;
		i = i + 1;
	}
	if (s == n)
		return true;
	else
		return false;
}

void LietKe(int a[][100], int m, int n, int x)
{
	if (x >= m)
		cout << "So dong khong phu hop";
	else
	{
		cout << "Cac so hoan thien tren dong " << x << " la: ";
		for (int j = 0; j < n; j++)
			if (ktHoanThien(a[x][j]))
				cout << setw(6) << a[x][j];
	}
}