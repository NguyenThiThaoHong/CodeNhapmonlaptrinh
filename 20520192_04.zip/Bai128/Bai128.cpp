#include <cstdlib>
#include <iostream>
#include <ctime>
#include <iomanip>
using namespace std;

void Nhap(float[][100], int&, int&);
void Xuat(float[][100], int, int);
void SapCotTang(float[][100], int, int, int);
void SapCotGiam(float[][100], int, int, int);
void HoanViTang(float&, float&);
void HoanViGiam(float&, float&);
void SapXep(float[][100], int, int);

int main()
{
	float b[100][100];
	int k, l;
	Nhap(b, k, l);
	cout << "Ma tran ban dau la: " << endl;
	Xuat(b, k, l);

	cout << "\nMa tran sau khi sap xep la: " << endl;
	SapXep(b, k, l);
	Xuat(b, k, l);

	return 1;
}

void Nhap(float a[][100], int& m, int& n)
{
	cout << "Nhap so dong: ";
	cin >> m;

	cout << "Nhap so cot: ";
	cin >> n;
	srand(time(nullptr));
	for (int i = 0; i < m; i++)
		for (int j = 0; j < n; j++)
			a[i][j] = -100.0 + (rand() / (RAND_MAX / (200.0)));
}

void Xuat(float a[][100], int m, int n)
{
	for (int i = 0; i < m; i++)
	{
		for (int j = 0; j < n; j++)
			cout << setw(7) << setprecision(3) << a[i][j];
		cout << endl;
	}
}

void HoanViTang(float& m, float& n)
{
	float lc = m;
	if (n < m)
	{
		float temp = m;
		m = n;
		n = temp;
	}
}

void HoanViGiam(float& m, float& n)
{
	float lc = m;
	if (n > m)
	{
		float temp = m;
		m = n;
		n = temp;
	}
}

void SapCotTang(float a[][100], int m, int n, int c)
{
	for (int i = 0; i <= m - 2; i++)
		for (int j = i + 1; j <= m - 1; j++)
			HoanViTang(a[i][c], a[j][c]);
}

void SapCotGiam(float a[][100], int m, int n, int c)
{
	for (int i = 0; i <= m - 2; i++)
		for (int j = i + 1; j <= m - 1; j++)
			HoanViGiam(a[i][c], a[j][c]);
}

void SapXep(float a[][100], int m, int n)
{
	for (int j = 0; j <= n - 1; j++)
	{
		if (j % 2 == 0)
			SapCotGiam(a, m, n, j);
		else
			SapCotTang(a, m, n, j);
	}
}
