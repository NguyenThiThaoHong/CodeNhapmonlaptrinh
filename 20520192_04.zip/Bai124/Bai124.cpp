#include <cstdlib>
#include <iostream>
#include <ctime>
#include <iomanip>
using namespace std;
void Nhap(float[][100], int&, int&);
void Xuat(float[][100], int, int);
void SapDongGiam(float[][100], int, int, int);
void HoanVi(float&, float&);

int main()
{
	float b[100][100];
	int k, l;
	Nhap(b, k, l);
	cout << "Ma tran ban dau la: \n";
	Xuat(b, k, l);
	int x;
	cout << "Nhap dong can xuat giam: ";
	cin >> x;
	cout << "Ma tran sau khi sap dong " << x << " theo thu tu giam dan la: " << endl;
	SapDongGiam(b, k, l, x);
	Xuat(b, k, l);

	return 1;
}

void Nhap(float a[][100], int& m, int& n)
{
	cout << "Nhap so dong: ";
	cin >> m;

	cout << "Nhap so cot: ";
	cin >> n;
	srand(time(nullptr));
	for (int i = 0; i < m; i++)
		for (int j = 0; j < n; j++)
			a[i][j] = -100.0 + (rand() / (RAND_MAX / (200.0)));
}

void Xuat(float a[][100], int m, int n)
{
	for (int i = 0; i < m; i++)
	{
		for (int j = 0; j < n; j++)
			cout << setw(7) << setprecision(3) << a[i][j];
		cout << endl;
	}
}

void HoanVi(float& m, float& n)
{
	float lc = m;
	if (n > m)
	{
		float temp = m;
		m = n;
		n = temp;
	}
}

void SapDongGiam(float a[][100], int m, int n, int d)
{
	for (int i = 0; i <= n - 2; i++)
		for (int j = i + 1; j <= n - 1; j++)
			HoanVi(a[d][i], a[d][j]);
}
