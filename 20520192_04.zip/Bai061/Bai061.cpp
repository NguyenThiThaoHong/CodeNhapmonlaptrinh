#include <iostream>
#include <cstdlib>
#include <ctime>
#include <iomanip>
using namespace std;

void Nhap(int[][100], int&, int&);
void Xuat(int[][100], int, int);
bool ktHoanThien(int);
int DemHoanThien(int[][100], int, int, int);

int main()
{
	int b[100][100];
	int k, l;

	Nhap(b, k, l);
	cout << "Mang tran ban dau: " << endl;
	Xuat(b, k, l);

	int row;
	cout << "Nhap dong can dem: ";
	cin >> row;

	cout << "So luong so hoan thien tren dong " << row << " la: " << DemHoanThien(b, k, l, row);

	return 0;
}

void Nhap(int a[][100], int& m, int& n)
{
	cout << "Nhap so dong: ";
	cin >> m;
	cout << "Nhap so cot: ";
	cin >> n;

	srand(time(nullptr));

	for (int i = 0; i < m; i++)
		for (int j = 0; j < n; j++)
			a[i][j] = (rand() % 201) - 100;
}

void Xuat(int a[][100], int m, int n)
{
	for (int i = 0; i < m; i++)
	{
		for (int j = 0; j < n; j++)
			cout << setw(7) << a[i][j];
		cout << endl;
	}
}

bool ktHoanThien(int n)
{
	int s = 0, i = 1;
	while (i < n)
	{
		if (n % i == 0)
			s = s + i;
		i = i + 1;
	}
	if (s == n)
		return true;
	else
		return false;
}

int DemHoanThien(int a[][100], int m, int n, int d)
{
	int dem = 0;
	if (d >= m)
		cout << "So dong khong phu hop";
	else
	{
		for (int j = 0; j < n; j++)
		{
			if (ktHoanThien(a[d][j]))
				dem++;
		}
	}
	return dem;
}