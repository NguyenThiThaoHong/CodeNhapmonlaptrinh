#include <iostream>
#include <cstdlib>
#include <ctime>
#include <iomanip>
using namespace std;

void Nhap(int[][100], int&, int&);
void Xuat(int[][100], int, int);
bool ktDang5m(int);
int Tong5m(int[][100], int, int);

int main()
{
	int b[100][100];
	int k, l;

	Nhap(b, k, l);
	cout << "Mang tran ban dau: " << endl;
	Xuat(b, k, l);

	cout << "Tong cac gia tri co dang 5^m nam tren bien cua ma tran la: " << Tong5m(b, k, l);

	return 0;
}

void Nhap(int a[][100], int& m, int& n)
{
	cout << "Nhap so dong: ";
	cin >> m;
	cout << "Nhap so cot: ";
	cin >> n;

	srand(time(nullptr));

	for (int i = 0; i < m; i++)
		for (int j = 0; j < n; j++)
			a[i][j] = rand() % 201 + 1;
}

void Xuat(int a[][100], int m, int n)
{
	for (int i = 0; i < m; i++)
	{
		for (int j = 0; j < n; j++)
			cout << setw(7) << a[i][j];
		cout << endl;
	}
}

bool ktDang5m(int n)
{
	int flag = 1;
	int t = n;
	while (t > 1)
	{
		int du = t % 5;
		if (du != 0)
			flag = 0;
		t = t / 5;
	}
	if (flag == 1)
		return true;
	else
		return false;
}

int Tong5m(int a[][100], int m, int n)
{
	float s = 0;
	for (int j = 0; j <= n - 2; j++)
		if (ktDang5m(a[0][j]))
			s = s + a[0][j];
	for (int i = 0; i <= m - 2; i++)
		if (ktDang5m(a[i][n - 1]))
			s = s + a[i][n - 1];
	for (int j = n - 1; j >= 1; j--)
		if (ktDang5m(a[m - 1][j]))
			s = s + a[m - 1][j];
	for (int i = m - 1; i >= 1; i--)
		if (ktDang5m(a[i][0]))
			s = s + a[i][0];
	return s;
}