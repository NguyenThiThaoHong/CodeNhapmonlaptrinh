#include <iostream>
#include <cstdlib>
#include <ctime>
#include <iomanip>
using namespace std;

void Nhap(float[][100], int&, int&);
void Xuat(float[][100], int, int);
void TimConToanDuong(float[][100], int, int, int&, int&, int&, int&);
bool ktToanDuong(float[][100], int, int, int&, int&, int&, int&);
void XuatConToanDuong(float[][100], int, int, int&, int&, int&, int&);

int main()
{
	float b[100][100];
	int k, l;
	int s, q, r, t;

	Nhap(b, k, l);
	cout << "Ma tran ban dau: " << endl;
	Xuat(b, k, l);

	TimConToanDuong(b, k, l, s, q, r, t);
	cout << "Mang con toan duong la: " << endl;
	XuatConToanDuong(b, k, l, s, q, r, t);

	return 0;
}

void Nhap(float a[][100], int& m, int& n)
{
	cout << "Nhap so dong: ";
	cin >> m;
	cout << "Nhap so cot: ";
	cin >> n;

	srand(time(nullptr));

	for (int i = 0; i < m; i++)
		for (int j = 0; j < n; j++)
			a[i][j] = -100 + rand() / (RAND_MAX / 200.0);
}

void Xuat(float a[][100], int m, int n)
{
	for (int i = 0; i < m; i++)
	{
		for (int j = 0; j < n; j++)
			cout << setw(7) << fixed << setprecision(2) << a[i][j];
		cout << endl;
	}
}

void TimConToanDuong(float a[][100], int m, int n, int& s, int& q, int& r, int& t)
{
	float maxCon = a[0][0];

	for(int i=0;i<m;i++)
		for(int j=0;j<n;j++)
			for(int z=i;z<m;z++)
				for (int p = j; p < n; p++)
				{
					if (ktToanDuong(a, m, n, i, j, z, p))
					{
						float S = 0;
						for (int x = i; x <= z; x++)
							for (int y = j; y <= p; y++)
							{
								S += a[x][y];
								if (S > maxCon)
								{
									maxCon = S;
									s = i; q = j; r = z; t = p;
								}
							}
					}
				}
}

void XuatConToanDuong(float a[][100], int m, int n, int& s, int& q, int& r, int& t)
{
	for (int i = s; i <= r; i++)
	{
		for (int j = q; j <= t; j++)
			cout << setw(7) << fixed << setprecision(2) << a[i][j];
		cout << endl;
	}
}

bool ktToanDuong(float a[][100], int m, int n, int& s, int& q, int& r, int& t)
{
	for (int i = s; i <= r; i++)
	{
		for (int j = q; j <= t; j++)
			if (a[i][j] <= 0)
				return false;
	}
	return true;
}