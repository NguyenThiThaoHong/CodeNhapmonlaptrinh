#include <iostream>
#include <cstdlib>
#include <ctime>
#include <iomanip>

#define MAX 100

using namespace std;

void Nhap(int[][MAX], int&, int&);
void Xuat(int[][MAX], int, int);
int ktDang2m(int);
void LietKe(int[][MAX], int, int);

int main()
{
	int b[100][100];
	int k, l;

	Nhap(b, k, l);
	cout << "Mang tran ban dau: " << endl;
	Xuat(b, k, l);

	cout << "Cac so co dang 2^m trong mang la: ";
	LietKe(b, k, l);

	return 0;
}

void Nhap(int a[][100], int& m, int& n)
{
	cout << "Nhap so dong: ";
	cin >> m;
	cout << "Nhap so cot: ";
	cin >> n;

	srand(time(nullptr));

	for (int i = 0; i < m; i++)
	{
		for (int j = 0; j < n; j++)
			a[i][j] = rand() % 201 + 1;
	}
}

void Xuat(int a[][100], int m, int n)
{
	for (int i = 0; i < m; i++)
	{
		for (int j = 0; j < n; j++)
			cout << setw(7) << a[i][j];
		cout << endl;
	}
}

int ktDang2m(int n)
{
	int flag = 1;
	int t = n;
	while (t > 1)
	{
		int du = t % 2;
		if (du != 0)
			flag = 0;
		t = t / 2;
	}
	return flag;
}

void LietKe(int a[][MAX], int m, int n)
{
	for (int i = 0; i < m; i++)
	{
		for (int j = 0; j < n; j++)
			if (ktDang2m(a[i][j]))
				cout << setw(4) << a[i][j];
	}
}