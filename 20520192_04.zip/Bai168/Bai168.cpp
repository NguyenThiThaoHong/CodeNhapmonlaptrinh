#include <iostream>
#include <cstdlib>
#include <ctime>
#include <iomanip>
using namespace std;

void Nhap(int[][100], int&, int&);
void Xuat(int[][100], int, int);
int ktCon(int[][100], int, int, int, int);
void ConCuoi(int[][100], int, int, int&, int&);
void Xoay90(int[][100], int&, int&);
void Xoay180(int[][100], int&, int&);

int main()
{
	int b[100][100];
	int k, l;

	Nhap(b, k, l);
	cout << "Mang tran ban dau: " << endl;
	Xuat(b, k, l);

	int vtd, vtc;
	cout << "Mang con 3x3 toan am cuoi cung la: " << endl;
	ConCuoi(b, k, l, vtd, vtc);

	return 0;
}

void Nhap(int a[][100], int& m, int& n)
{
	cout << "Nhap so dong: ";
	cin >> m;
	cout << "Nhap so cot: ";
	cin >> n;

	srand(time(nullptr));

	for (int i = 0; i < m; i++)
		for (int j = 0; j < n; j++)
			a[i][j] = (rand() % 201) - 100;
}

void Xuat(int a[][100], int m, int n)
{
	for (int i = 0; i < m; i++)
	{
		for (int j = 0; j < n; j++)
			cout << setw(7) << a[i][j];
		cout << endl;
	}
}

int ktCon(int a[][100], int m, int n, int vtd, int vtc)
{
	int flag = 1;
	for (int i = 0; i < 3; i++)
		for (int j = 0; j < 3; j++)
			if (a[vtd - i][vtc - j] >= 0)
				flag = 0;
	return flag;
}

void Xoay90(int a[][100], int& m, int& n)
{
	int b[100][100];
	int k, l;

	k = n;
	l = m;

	for (int i = 0; i < k; i++)
		for (int j = 0; j < l; j++)
			b[i][j] = a[j][n - 1 - i];

	m = k;
	n = l;

	for (int i = 0; i < m; i++)
		for (int j = 0; j < n; j++)
			a[i][j] = b[i][j];
}

void Xoay180(int a[][100], int& m, int& n)
{
	Xoay90(a, m, n);
	Xoay90(a, m, n);
}

void ConCuoi(int a[][100], int m, int n, int& vtd, int& vtc)
{
	for(int vtd = m - 1; vtd >= 3; vtd--)
		for(int vtc = n - 1; vtc >= 3; vtc--)
			if (ktCon(a, m, n, vtd, vtc) == 1)
			{
				int b[100][100];
				int i, j, k, l;
				for (i = vtd, k = 0; i > vtd - 3, k < 3; i--, k++)
					for (j = vtc, l = 0; j > vtc - 3, l < 3; j--, l++)
						b[k][l] = a[i][j];
				Xoay180(b, k, l);
				Xuat(b, k, l);
				return;
			}
	vtd = vtc = -1;
}