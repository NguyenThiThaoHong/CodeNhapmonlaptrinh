#include <cstdlib>
#include <iostream>
#include < ctime>
#include <iomanip>
using namespace std;

void Nhap(int[][100], int&, int&);
void Xuat(int[][100], int, int);
int ChanLonNhat(int[][100], int, int);
int ChanDau(int[][100], int, int);

int main()
{
	int b[100][100];
	int k, l;
	Nhap(b, k, l);
	cout << "Ma tran ban dau : " << endl;
	Xuat(b, k, l);
	cout << " Gia tri  chan lon nhat trong ma tran la: " << ChanLonNhat(b, k, l);
	return 1;
}

void Nhap(int a[][100], int& m, int& n)
{
	cout << " Nhap so dong: ";
	cin >> m;
	cout << " Nhap so cot: ";
	cin >> n;
	srand(time(nullptr));
	for (int i = 0; i < m; i++)
		for (int j = 0; j < n; j++)
			a[i][j] = rand() % (200 + 1) - 100;
}

void Xuat(int a[][100], int m, int n)
{
	for (int i = 0; i < m; i++)
	{
		for (int j = 0; j < n; j++)
			cout << setw(7) << a[i][j];
		cout << endl;
	}
}

int ChanLonNhat(int a[][100], int m, int n)
{
	float ln = ChanDau(a, m, n);
	for (int i = 0; i < m; i++)
		for (int j = 0; j < n; j++)
			if (a[i][j] % 2 == 0 && a[i][j] > ln)
				ln = a[i][j];
	return ln;
}
int ChanDau(int a[][100], int m, int n)
{
	for (int i = 0; i < m; i++)
		for (int j = 0; j < n; j++)
			if (a[i][j] % 2 == 0)
				return a[i][j];
	return 0;
}
