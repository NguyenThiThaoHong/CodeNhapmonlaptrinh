#include <cstdlib>
#include <iostream>
#include <ctime>
#include <iomanip>
using namespace std;

void Nhap(float[][100], int&, int&);
void Xuat(float[][100], int, int);
void XoaCot(float[][100], int, int&, int);

int main()
{
	float b[100][100];
	int k, l;
	Nhap(b, k, l);
	cout << "Ma tran ban dau la: " << endl;
	Xuat(b, k, l);

	int x;
	cout << "Nhap cot can xoa: ";
	cin >> x;

	cout << "Ma tran sau khi xoa cot " << x << " la: " << endl;
	XoaCot(b, k, l, x);
	Xuat(b, k, l);

	return 1;
}

void Nhap(float a[][100], int& m, int& n)
{
	cout << "Nhap so dong: ";
	cin >> m;

	cout << "Nhap so cot: ";
	cin >> n;
	srand(time(nullptr));
	for (int i = 0; i < m; i++)
		for (int j = 0; j < n; j++)
			a[i][j] = -100.0 + (rand() / (RAND_MAX / (200.0)));
}

void Xuat(float a[][100], int m, int n)
{
	for (int i = 0; i < m; i++)
	{
		for (int j = 0; j < n; j++)
			cout << setw(7) << setprecision(3) << a[i][j];
		cout << endl;
	}
}

void XoaCot(float a[][100], int m, int& n, int c)
{
	for (int i = 0; i < m; i++)
	{
		for (int j = c; j <= n - 2; j++)
			a[i][j] = a[i][j + 1];
	}
	n--;
}
