#include <iostream>
#include <iomanip>
#include <ctime>
#include <cstdlib>

using namespace std;

void Nhap(int[][100], int&, int&);
void TimConLonNhat(int[][100], int, int, int&, int&, int&, int&);
void Xuat(int[][100], int, int, int, int, int, int);

int main()
{
	int b[100][100];
	int k, l;
	int d1x, d1y, d2x, d2y;
	Nhap(b, k, l);
	cout << "Ma tran ban dau: " << endl;
	TimConLonNhat(b, k, l, d1x, d1y, d2x, d2y);
	Xuat(b, k, l, d1x, d1y, d2x, d2y);
}

void Nhap(int a[][100], int& m, int& n)
{
	cout << "Nhap so dong: ";
	cin >> m;
	cout << "Nhap so cot: ";
	cin >> n;

	srand(time(nullptr));

	for (int i = 0; i < m; i++)
		for (int j = 0; j < n; j++)
			a[i][j] = (rand() % 201) - 100;
}

void TimConLonNhat(int a[][100], int m, int n, int& sx, int& sy, int& fx, int& fy)
{
	float maxCon = a[0][0];

	for (int i = 0; i <= m - 1; i++)
		for (int j = 0; j <= n - 1; j++)
			for (int r = i; r <= m - 1; r++)
				for (int c = j; c <= n - 1; c++)
				{
					int S = 0;
					for (int x = i; x <= r; x++)
						for (int y = j; y <= c; y++)
						{
							S += a[x][y];
							if (S > maxCon)
							{
								maxCon = S;
								sx = i; sy = j; fx = r; fy = c;
							}
						}
				}

}

void Xuat(int a[][100], int m, int n, int sx, int sy, int fx, int fy)
{
	for (int i = 0; i < m; i++)
	{
		for (int j = 0; j < n; j++)
			cout << setw(7) << a[i][j];
		cout << endl;
	}

	cout << "Mang con: " << endl;
	for (int i = sx; i <= fx; i++)
	{
		for (int j = sy; j <= fy; j++)
			cout << setw(7) << a[i][j];
		cout << endl;
	}
}