#include <iostream>
#include <cstdlib>
#include <ctime>
#include <iomanip>
using namespace std;

void Nhap(int[][100], int&, int&);
void Xuat(int[][100], int, int);
void ThemDong(int[][100], int, int&, int);

int main()
{
	int b[100][100];
	int k, l;

	Nhap(b, k, l);
	cout << "Mang tran ban dau: " << endl;
	Xuat(b, k, l);

	int col;
	cout << "Nhap cot can them: ";
	cin >> col;

	cout << "Ma tran sau khi them cot toan gia tri 0 la: " << endl;
	ThemDong(b, k, l, col);
	Xuat(b, k, l);

	return 0;
}

void Nhap(int a[][100], int& m, int& n)
{
	cout << "Nhap so dong: ";
	cin >> m;
	cout << "Nhap so cot: ";
	cin >> n;

	srand(time(nullptr));

	for (int i = 0; i < m; i++)
		for (int j = 0; j < n; j++)
			a[i][j] = (rand() % 201) - 100;
}

void Xuat(int a[][100], int m, int n)
{
	for (int i = 0; i < m; i++)
	{
		for (int j = 0; j < n; j++)
			cout << setw(7) << a[i][j];
		cout << endl;
	}
}

void ThemDong(int a[][100], int m, int& n, int c)
{
	if (c >= 0 && c <= n)
	{
		for (int i = 0; i < m; i++)
		{
			for (int j = n; j > c; j--)
			{
				a[i][j] = a[i][j - 1];
			}
			a[i][c] = 0;
		}
		n++;
	}
}