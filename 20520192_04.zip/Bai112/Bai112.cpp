#include <cstdlib>
#include <iostream>
#include <ctime>
#include <iomanip>
using namespace std;

void Nhap(float[][100], int&, int&);
void Xuat(float[][100], int, int);
void LietKe(float[][100], int, int);

int main()
{
	float b[100][100];
	int k, l;

	Nhap(b, k, l);
	cout << "Ma tran ban dau: " << endl;
	Xuat(b, k, l);

	LietKe(b, k, l);
	return 0;
}

void Nhap(float a[][100], int& m, int& n)
{
	cout << "Nhap so dong: ";
	cin >> m;
	cout << "Nhap so cot: ";
	cin >> n;
	srand(std::time(nullptr));
	for (int i = 0; i < m; i++)
		for (int j = 0; j < n; j++)
			a[i][j] = -100 + rand() / (RAND_MAX / 200.0);
}

void Xuat(float a[][100], int m, int n)
{
	for (int i = 0; i < m; i++)
	{
		for (int j = 0; j < n; j++)
			cout << setw(7) << setprecision(3) << a[i][j];
		cout << endl;
	}
}

void LietKe(float a[][100], int m, int n)
{
	int tich = m * n;
	int i, j;
	for (i = 0; i < m; i++)
	{
		if (tich > 2)
		{
			int flag[3] = { 0 };
			for (j = 0; j < n; j++)
			{
				if (a[i][j] < 0)
					flag[0] = 1;
				else if (a[i][j] == 0)
					flag[1] = 1;
				else if (a[i][j] > 0)
					flag[2] = 1;
				if (flag[0] + flag[1] + flag[2] == 3)
				{
					cout << "\nDong  co phan tu am, duong, 0", i;
					break;
				}
			}
		}
	}
}

