#include <iostream>
#include <iomanip>
#include <cstring>
#include <fstream>

#define MAX 100

using namespace std;

void Nhap(string, float[][MAX], int&, int&);
void Xuat(float[][MAX], int, int);

int main()
{
	float b[MAX][MAX];
	int k, l;

	string filename = "D:\\Luu_do _thuat _toan\\Chuong04\\Bai002\\data06.inp";
	Nhap(filename, b, k, l);
	Xuat(b, k, l);
	return 1;
}

void Nhap(string filename, float a[][MAX], int& m, int& n)
{
	ifstream myfile(filename);

	myfile >> m;
	myfile >> n;

	for (int i = 0; i < m; i++)
		for (int j = 0; j < n; j++)
			myfile >> a[i][j];
}

void Xuat(float a[][100], int m, int n)
{
	cout << "Nhap so dong: " << m << endl;
	cout << "Nhap so cot: " << n << endl;

	cout << "Mang tran ban dau: " << endl;
	for (int i = 0; i < m; i++)
	{
		for (int j = 0; j < n; j++)
			cout << setw(7) << a[i][j];
		cout << endl;
	}
}