#include <iostream>
#include <cstdlib>
#include <ctime>
#include <iomanip>
using namespace std;

void Nhap(int[][100], int&, int&);
void Xuat(int[][100], int, int);
void HoanVi(int&, int&);
void TopRight(int[][100], int, int, int, int, int[], int);
void BottomLeft(int[][100], int, int, int, int, int[], int);

int main()
{
	int b[100][100];
	int k, l;

	Nhap(b, k, l);
	cout << "Mang tran ban dau: " << endl;
	Xuat(b, k, l);

	int mang[100];
	int phantu = 0;

	for (int i = 0; i < k; i++)
		for (int j = 0; j < l; j++)
			mang[phantu++] = b[i][j];

	for (int i = 0; i < phantu - 1; i++)
		for (int j = i + 1; j < phantu; j++)
			if (mang[j] < mang[i])
				HoanVi(mang[i], mang[j]);								

	int bienphu = 0;
	cout << "Ma tran xoan oc la: " << endl;
	TopRight(b, 0, 0, l - 1, k - 1, mang, bienphu);
	Xuat(b, k, l);

	return 0;
}

void Nhap(int a[][100], int& m, int& n)
{
	cout << "Nhap so dong: ";
	cin >> m;
	cout << "Nhap so cot: ";
	cin >> n;

	srand(time(nullptr));

	for (int i = 0; i < m; i++)
		for (int j = 0; j < n; j++)
			a[i][j] = (rand() % 201) - 100;
}

void Xuat(int a[][100], int m, int n)
{
	for (int i = 0; i < m; i++)
	{
		for (int j = 0; j < n; j++)
			cout << setw(7) << a[i][j];
		cout << endl;
	}
}

void HoanVi(int& a, int& b)
{
	int temp = a;
	a = b;
	b = temp;
}

void TopRight(int a[][100], int x1, int y1, int x2, int y2, int b[], int x)
{
	for (int i = x1; i <= x2; i++)
		a[y1][i] = b[x++];
	for (int j = y1 + 1; j <= y2; j++)
		a[j][x2] = b[x++];
	if (x2 - x1 > 0 && y2 - y1 > 0)
	{
		x2--;
		y1++;
		BottomLeft(a, x1, y1, x2, y2, b, x);
	}
}

void BottomLeft(int a[][100], int x1, int y1, int x2, int y2, int b[], int x)
{
	for (int i = x2; i >= x1; i--)
		a[y2][i] = b[x++];
	for (int j = y2 - 1; j >= y1; j--)
		a[j][x1] = b[x++];
	if (x2 - x1 > 0 && y2 - y1 > 0)
	{
		x1++;
		y2--;
		TopRight(a, x1, y1, x2, y2, b, x);
	}
}
