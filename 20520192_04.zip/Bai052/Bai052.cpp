#include <iostream>
#include <cstdlib>
#include <ctime>
#include <iomanip>
using namespace std;

void Nhap(float[][100], int&, int&);
void Xuat(float[][100], int, int);
bool ktCucDai(float[][100], int, int, int, int);
bool ktCucTieu(float[][100], int, int, int, int);
float TongCucDai(float[][100], int, int);
float TongCucTieu(float[][100], int, int);
float TongCucTri(float[][100], int, int);

int main()
{
	float b[100][100];
	int k, l;

	Nhap(b, k, l);
	cout << "Mang tran ban dau: " << endl;
	Xuat(b, k, l);

	cout << "Tong cac phan tu cuc tri trong mang la: " << TongCucTri(b, k, l);
	return 0;
}

void Nhap(float a[][100], int& m, int& n)
{
	cout << "Nhap so dong: ";
	cin >> m;
	cout << "Nhap so cot: ";
	cin >> n;

	srand(time(nullptr));

	for (int i = 0; i < m; i++)
		for (int j = 0; j < n; j++)
			a[i][j] = -100 + rand() / (RAND_MAX / 200.0);
}

void Xuat(float a[][100], int m, int n)
{
	for (int i = 0; i < m; i++)
	{
		for (int j = 0; j < n; j++)
			cout << setw(7) << fixed << setprecision(2) << a[i][j];
		cout << endl;
	}
}

bool ktCucDai(float a[][100], int m, int n, int x, int y)
{
	int di[8] = { -1, -1, -1, 0, 1, 1, 1, 0 };
	int dj[8] = { -1, 0, 1, 1, 1, 0, -1, -1 };
	float phantu = a[x][y];
	bool max = true;
	for (int i = 0; i < 8; i++)
	{
		if (x + di[i] >= 0 && x + di[i] < m && y + dj[i] >= 0 && y + dj[i] < n)
		{
			if (phantu < a[x + di[i]][y + dj[i]])
				max = false;
		}
	}
	return max;
}

bool ktCucTieu(float a[][100], int m, int n, int x, int y)
{
	int di[8] = { -1, -1, -1, 0, 1, 1, 1, 0 };
	int dj[8] = { -1, 0, 1, 1, 1, 0, -1, -1 };
	float phantu = a[x][y];
	bool min = true;
	for (int i = 0; i < 8; i++)
	{
		if (x + di[i] >= 0 && x + di[i] < m && y + dj[i] >= 0 && y + dj[i] < n)
		{
			if (phantu > a[x + di[i]][y + dj[i]])
				min = false;
		}
	}
	return min;
}

float TongCucDai(float a[][100], int m, int n)
{
	float s = 0;
	for (int i = 0; i < m; i++)
		for (int j = 0; j < n; j++)
			if (ktCucDai(a, m, n, i, j))
				s = s + a[i][j];
	return s;
}

float TongCucTieu(float a[][100], int m, int n)
{
	float s = 0;
	for (int i = 0; i < m; i++)
		for (int j = 0; j < n; j++)
			if (ktCucTieu(a, m, n, i, j))
				s = s + a[i][j];
	return s;
}

float TongCucTri(float a[][100], int m, int n)
{
	float tongcudai = TongCucDai(a, m, n);
	float tongcuctieu = TongCucTieu(a, m, n);
	return (tongcudai + tongcuctieu);
}