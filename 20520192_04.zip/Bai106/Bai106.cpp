#include <cstdlib>
#include <iostream>
#include <ctime>
#include <iomanip>
using namespace std;

void Nhap(float[][100], int&, int&);
void Xuat(float[][100], int, int);
int ktDongTang(float[][100], int, int, int);

int main()
{
	float b[100][100];
	int k, l;

	Nhap(b, k, l);
	cout << "Ma tran ban dau: " << endl;
	Xuat(b, k, l);

	int x;
	do
	{
		cout << "Nhap dong can kiem tra: ";
		cin >> x;
	} while (x < 0 || x >= k);

	int flag = ktDongTang(b, k, l, x);;
	if (flag == 1)
		cout << "Dong " << x << " tang dan";
	else
		cout << "Dong " << x << " khong tang dan";
	return 0;
}

void Nhap(float a[][100], int& m, int& n)
{
	cout << "Nhap so dong: ";
	cin >> m;
	cout << "Nhap so cot: ";
	cin >> n;
	srand(std::time(nullptr));
	for (int i = 0; i < m; i++)
		for (int j = 0; j < n; j++)
			a[i][j] = -100 + rand() / (RAND_MAX / 200.0);
}

void Xuat(float a[][100], int m, int n)
{
	for (int i = 0; i < m; i++)
	{
		for (int j = 0; j < n; j++)
			cout << setw(7) << setprecision(3) << a[i][j];
		cout << endl;
	}
}

int ktDongTang(float a[][100], int m, int n, int x)
{
	int flag = 1;
	for (int j = 0; j < n - 1; j++)
	{
		for (int k = j + 1; k < n; k++)
		{
			if (a[x][j] > a[x][k])
			{
				flag = 0;
				break;
			}
		}
	}
	return flag;
}
