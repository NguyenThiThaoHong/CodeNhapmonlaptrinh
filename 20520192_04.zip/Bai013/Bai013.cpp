#include <iostream>
#include <cstdlib>
#include <ctime>
#include <iomanip>

#define MAX 100

using namespace std;

void Nhap(int[][MAX], int&, int&);
void Xuat(int[][MAX], int, int);
int ktToanChan(int);
void LietKe(int[][MAX], int, int);

int main()
{
	int b[100][100];
	int k, l;

	Nhap(b, k, l);
	cout << "Mang tran ban dau: " << endl;
	Xuat(b, k, l);

	cout << "Cac so nguyen toan chu so chan trong mang la: ";
	LietKe(b, k, l);

	return 0;
}

void Nhap(int a[][100], int& m, int& n)
{
	cout << "Nhap so dong: ";
	cin >> m;
	cout << "Nhap so cot: ";
	cin >> n;

	srand(time(nullptr));

	for (int i = 0; i < m; i++)
	{
		for (int j = 0; j < n; j++)
			a[i][j] = (rand() % 201) - 100;
	}
}

void Xuat(int a[][100], int m, int n)
{
	for (int i = 0; i < m; i++)
	{
		for (int j = 0; j < n; j++)
			cout << setw(7) << a[i][j];
		cout << endl;
	}
}

int ktToanChan(int n)
{
	int flag = 1;
	int t = abs(n);
	while (t > 0)
	{
		int dv = t % 10;
		if (dv % 2 != 0)
			flag = 0;
		t = t / 10;
	}
	return flag;
}

void LietKe(int a[][MAX], int m, int n)
{
	for (int i = 0; i < m; i++)
	{
		for (int j = 0; j < n; j++)
			if (ktToanChan(a[i][j]))
				cout << setw(4) << a[i][j];
	}
}