#include <iostream>
#include <cstdlib>
#include <ctime>
#include <iomanip>
using namespace std;

void Nhap(int[][100], int&, int&);
void Xuat(int[][100], int, int);
int DemChuSo(int);
int DemChuSo(int[][100], int, int);

int main()
{
	int b[100][100];
	int k, l;

	Nhap(b, k, l);
	cout << "Mang tran ban dau: " << endl;
	Xuat(b, k, l);

	cout << "So luong cac chu so trong ma tran la: " << DemChuSo(b, k, l);

	return 0;
}

void Nhap(int a[][100], int& m, int& n)
{
	cout << "Nhap so dong: ";
	cin >> m;
	cout << "Nhap so cot: ";
	cin >> n;

	srand(time(nullptr));

	for (int i = 0; i < m; i++)
		for (int j = 0; j < n; j++)
			a[i][j] = (rand() % 201) - 100;
}

void Xuat(int a[][100], int m, int n)
{
	for (int i = 0; i < m; i++)
	{
		for (int j = 0; j < n; j++)
			cout << setw(7) << a[i][j];
		cout << endl;
	}
}

int DemChuSo(int n)
{
	int s = 0;
	int dem[10] = { 0,0,0,0,0,0,0,0,0,0 };
	dem[0] = 0;
	if (n == 0)
		dem[0]++;
	int t = abs(n);
	while (t != 0)
	{
		int dv = t % 10;
		dem[dv]++;
		t = t / 10;
	}
	for (int i = 0; i < 10; i++)
		s = s + dem[i];
	return s;
}

int DemChuSo(int a[][100], int m, int n)
{
	int s = 0;
	for (int i = 0; i < m; i++)
		for (int j = 0; j < n; j++)
			s = s + DemChuSo(a[i][j]);
	return s;
}