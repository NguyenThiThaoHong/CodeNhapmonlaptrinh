#include <iostream>
#include <iomanip>
#include <ctime>
#include <cstdlib>

using namespace std;

void Nhap(float[][100], int&, int&);
void TimConLonNhat(float[][100], int, int, int&, int&, int&, int&);
void Xuat(float[][100], int, int, int, int, int, int);

int main()
{
	float b[100][100];
	int k, l;
	int d1x, d1y, d2x, d2y;
	Nhap(b, k, l);
	cout << "Ma tran ban dau: " << endl;
	TimConLonNhat(b, k, l, d1x, d1y, d2x, d2y);
	Xuat(b, k, l, d1x, d1y, d2x, d2y);
}

void Nhap(float a[][100], int& n, int& m)
{
	srand(time(NULL));
	cout << "Nhap so hang: ";
	cin >> n;
	cout << "Nhap so cot: ";
	cin >> m;
	for (int i = 0; i <= n - 1; i++)
		for (int j = 0; j <= m - 1; j++)
			a[i][j] = -100 + rand() / (RAND_MAX / 200.0);
}

void TimConLonNhat(float a[][100], int n, int m, int& sx, int& sy, int& fx, int& fy)
{
	float maxCon = a[0][0];

	for (int i = 0; i <= n - 1; i++)
		for (int j = 0; j <= m - 1; j++)
			for (int r = i; r <= n - 1; r++)
				for (int c = j; c <= m - 1; c++)
				{
					float S = 0;
					for (int x = i; x <= r; x++)
						for (int y = j; y <= c; y++)
						{
							S += a[x][y];
							if (S > maxCon)
							{
								maxCon = S;
								sx = i; sy = j; fx = r; fy = c;
							}
						}
				}

}

void Xuat(float a[][100], int n, int m, int sx, int sy, int fx, int fy)
{
	for (int i = 0; i <= n - 1; i++)
	{
		for (int j = 0; j <= m - 1; j++)
			cout << setw(7) << setprecision(3) << a[i][j] << " ";
		cout << endl;
	}

	cout << "Mang con: " << endl;
	for (int i = sx; i <= fx; i++)
	{
		for (int j = sy; j <= fy; j++)
			cout << setw(7) << setprecision(3) << a[i][j] << " ";
		cout << endl;
	}
}