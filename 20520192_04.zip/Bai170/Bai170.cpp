#include <iostream>
#include <cstdlib>
#include <ctime>
#include <iomanip>
using namespace std;

void Nhap(float[][100], int&, int&);
void Xuat(float[][100], int, int);
int ktCon(float[][100], int, int, float[][100], int, int);

int main()
{
	float b[100][100], c[100][100];
	int k, l, m, n;

	cout << "Nhap ma tran A: " << endl;
	Nhap(b, k, l);
	cout << "Ma tran A la: " << endl;
	Xuat(b, k, l);

	cout << "Nhap ma tran B: " << endl;
	Nhap(c, m, n);
	cout << "Ma tran B la: " << endl;
	Xuat(c, m, n);

	int kq = ktCon(b, k, l, c, k, n);
	if (kq == 1)
		cout << "A la ma tran con cua B";
	else
		cout << "A khong la ma tran con cua B";

	return 0;
}

void Nhap(float a[][100], int& m, int& n)
{
	cout << "Nhap so dong: ";
	cin >> m;
	cout << "Nhap so cot: ";
	cin >> n;

	srand(time(nullptr));

	for (int i = 0; i < m; i++)
		for (int j = 0; j < n; j++)
			a[i][j] = -100 + rand() / (RAND_MAX / 200.0);
}

void Xuat(float a[][100], int m, int n)
{
	for (int i = 0; i < m; i++)
	{
		for (int j = 0; j < n; j++)
			cout << setw(7) << fixed << setprecision(2) << a[i][j];
		cout << endl;
	}
}

int ktCon(float a[][100], int m, int n, float b[][100], int k, int l)
{
	if (m > k || n > l)
		return 0;
	int flag = 0;
	for(int d = 0;d <= k - m; d++)
		for (int c = 0; c <= l - n; c++)
		{
			int co = 1;
			for (int i = 0; i < m; i++)
				for (int j = 0; j < n; j++)
					if (a[i][j] != b[d + i][c + j])
						co = 0;
			if (co == 1)
				flag = 1;
		}
	return flag;
}