#include <iostream>
#include <cstdlib>
#include <ctime>
#include <iomanip>
using namespace std;

void Nhap(int[][100], int&, int&);
void Xuat(int[][100], int, int);
bool ktToanChan(int);
int DemToanChan(int[][100], int, int);

int main()
{
	int b[100][100];
	int k, l;

	Nhap(b, k, l);
	cout << "Mang tran ban dau: " << endl;
	Xuat(b, k, l);

	cout << "So luong so nguyen toan chu so chan la: " << DemToanChan(b, k, l);

	return 0;
}

void Nhap(int a[][100], int& m, int& n)
{
	cout << "Nhap so dong: ";
	cin >> m;
	cout << "Nhap so cot: ";
	cin >> n;

	srand(time(nullptr));

	for (int i = 0; i < m; i++)
		for (int j = 0; j < n; j++)
			a[i][j] = (rand() % 201) - 100;
}

void Xuat(int a[][100], int m, int n)
{
	for (int i = 0; i < m; i++)
	{
		for (int j = 0; j < n; j++)
			cout << setw(7) << a[i][j];
		cout << endl;
	}
}

bool ktToanChan(int n)
{
	int flag = 1;
	int t = abs(n);
	while (t > 0)
	{
		int dv = t % 10;
		if (dv % 2 != 0)
			flag = 0;
		t = t / 10;
	}
	if (flag == 1)
		return true;
	else
		return false;
}

int DemToanChan(int a[][100], int m, int n)
{
	int dem = 0;
	for (int i = 0; i < m; i++)
		for (int j = 0; j < n; j++)
			if (ktToanChan(a[i][j]))
				dem++;
	return dem;
}