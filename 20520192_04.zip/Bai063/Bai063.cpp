#include <iostream>
#include <cstdlib>
#include <ctime>
#include <iomanip>
using namespace std;

void Nhap(float[][100], int&, int&);
void Xuat(float[][100], int, int);
int DemAm(float[][100], int, int, int);

int main()
{
	float b[100][100];
	int k, l;

	Nhap(b, k, l);
	cout << "Ma tran ban dau: " << endl;
	Xuat(b, k, l);

	int col;
	cout << "Nhap cot can dem: ";
	cin >> col;

	cout << "So luong so am tren cot " << col << " la: " << DemAm(b, k, l, col);
	return 0;
}

void Nhap(float a[][100], int& m, int& n)
{
	cout << "Nhap so dong: ";
	cin >> m;
	cout << "Nhap so cot: ";
	cin >> n;

	srand(time(nullptr));

	for (int i = 0; i < m; i++)
		for (int j = 0; j < n; j++)
			a[i][j] = -100 + rand() / (RAND_MAX / 200.0);
}

void Xuat(float a[][100], int m, int n)
{
	for (int i = 0; i < m; i++)
	{
		for (int j = 0; j < n; j++)
			cout << setw(7) << fixed << setprecision(2) << a[i][j];
		cout << endl;
	}
}

int DemAm(float a[][100], int m, int n, int c)
{
	int dem = 0;
	if (c >= n)
		cout << "So cot khong phu hop";
	else
	{
		for (int i = 0; i < m; i++)
			if (a[i][c] < 0)
				dem++;
	}
	return dem;
}