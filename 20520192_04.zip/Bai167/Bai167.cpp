#include <iostream>
#include <ctime>
#include <cstdlib>
#include <iomanip>
using namespace std;

void Nhap(int[][100], int&, int&);
void Xuat(int[][100], int, int);
int ktCon(int[][100], int, int, int, int);
void ConDau(int[][100], int, int, int&, int&);

int main()
{
	int b[100][100];
	int k, l;

	Nhap(b, k, l);
	cout << "Mang tran ban dau: " << endl;
	Xuat(b, k, l);

	int vtd, vtc;
	cout << "Ma tran 3x3 toan duong dau tien: " << endl;
	ConDau(b, k, l, vtd, vtc);
	return 1;
}

void Nhap(int a[][100], int& m, int& n)
{
	cout << "Nhap so dong: ";
	cin >> m;
	cout << "Nhap so cot: ";
	cin >> n;

	srand(time(nullptr));

	for (int i = 0; i < m; i++)
		for (int j = 0; j < n; j++)
			a[i][j] = (rand() % 201) - 100;
}

void Xuat(int a[][100], int m, int n)
{
	for (int i = 0; i < m; i++)
	{
		for (int j = 0; j < n; j++)
			cout << setw(7) << a[i][j];
		cout << endl;
	}
}

int ktCon(int a[][100], int m, int n, int vtd, int vtc)
{
	int flag = 1;
	for (int i = 0; i < 3; i++)
		for (int j = 0; j < 3; j++)
			if (a[vtd + i][vtc + j] <= 0)
				flag = 0;
	return flag;
}

void ConDau(int a[][100], int m, int n, int& vtd, int& vtc)
{
	for (int vtd = 0; vtd <= m - 3; vtd++)
		for (int vtc = 0; vtc <= n - 3; vtc++)
			if (ktCon(a, m, n, vtd, vtc) == 1)
			{
				int b[100][100];
				int i, j, k, l;
				for (i = vtd, k = 0; i < vtd + 3, k < 3; i++, k++)
					for (j = vtc, l = 0; j < vtc + 3, l < 3; j++, l++)
						b[k][l] = a[i][j];
				Xuat(b, k, l);
				return;
			}
	vtd = vtc = -1;
}
