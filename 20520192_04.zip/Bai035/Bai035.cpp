#include <iostream>
#include <cstdlib>
#include <ctime>
#include <iomanip>

#define MAX 100

using namespace std;

void Nhap(int[][MAX], int&, int&);
void Xuat(int[][MAX], int, int);
bool ktDoiXung(int);
int TongDoiXung(int[][MAX], int, int, int);

int main()
{
	int b[100][100];
	int k, l;

	Nhap(b, k, l);
	cout << "Mang tran ban dau: " << endl;
	Xuat(b, k, l);

	int row;
	cout << "Nhap dong can tinh tong: ";
	cin >> row;

	cout << "Tong cac so doi xung tren dong " << row << " la: " << TongDoiXung(b, k, l, row);

	return 0;
}

void Nhap(int a[][100], int& m, int& n)
{
	cout << "Nhap so dong: ";
	cin >> m;
	cout << "Nhap so cot: ";
	cin >> n;

	srand(time(nullptr));

	for (int i = 0; i < m; i++)
		for (int j = 0; j < n; j++)
			a[i][j] = rand() % 201 + 1;
}

void Xuat(int a[][100], int m, int n)
{
	for (int i = 0; i < m; i++)
	{
		for (int j = 0; j < n; j++)
			cout << setw(6) << a[i][j];
		cout << endl;
	}
}

bool ktDoiXung(int n)
{
	n = abs(n);
	int dn = 0;
	int t = n;
	while (t != 0)
	{
		int dv = t % 10;
		dn = dn * 10 + dv;
		t = t / 10;
	}
	if (dn == n)
		return true;
	else
		return false;
}

int TongDoiXung(int a[][MAX], int m, int n,int x)
{
	int s = 0;
	if (x >= m)
		cout << "So dong khong phu hop" << endl;
	else
	{
		for (int j = 0; j < n; j++)
			if (ktDoiXung(a[x][j]))
				s = s + a[x][j];
	}
	return s;
}