#include <iostream>
#include <cstdlib>
#include <ctime>
#include <iomanip>
using namespace std;

void Nhap(int[][100], int&, int&);
void Xuat(int[][100], int, int);
void LietKe(int[][100], int, int);

int main()
{
	int b[100][100];
	int k, l;

	Nhap(b, k, l);
	cout << "Mang tran ban dau: " << endl;
	Xuat(b, k, l);

	cout << "Cac gia tri nam tren bien cua ma tran la: ";
	LietKe(b, k, l);

	return 0;
}

void Nhap(int a[][100], int& m, int& n)
{
	cout << "Nhap so dong: ";
	cin >> m;
	cout << "Nhap so cot: ";
	cin >> n;

	srand(time(nullptr));

	for (int i = 0; i < m; i++)
	{
		for (int j = 0; j < n; j++)
			a[i][j] = (rand() % 201) - 100;
	}
}

void Xuat(int a[][100], int m, int n)
{
	for (int i = 0; i < m; i++)
	{
		for (int j = 0; j < n; j++)
			cout << setw(5) << a[i][j];
		cout << endl;
	}
}

void LietKe(int a[][100], int m, int n)
{
	/*for (int i = 0; i < m; i++)
	{
		for (int j = 0; j < n; j++)
			if (i == 0 || j == 0 || i == m - 1 || j == n - 1)
				cout << setw(5) << a[i][j];
	}*/
	for (int j = 0; j < n; j++)
		cout << setw(5) << a[0][j];
	for (int i = 1; i < m - 1; i++)
		cout << setw(5) << a[i][n - 1];
	for (int j = n - 1; j >= 0; j--)
		cout << setw(5) << a[m - 1][j];
	for (int i = m - 2; i >= 1; i--)
		cout << setw(5) << a[i][0];
}