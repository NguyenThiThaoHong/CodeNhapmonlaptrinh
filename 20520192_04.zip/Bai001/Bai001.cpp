#include <iostream>
#include <cstdlib>
#include <ctime>
#include <iomanip>
#include <cstring>
#include <fstream>

#define MAX 100

using namespace std;

void Nhap(int[][MAX], int&, int&);
void Xuat(int[][MAX], int, int);
void Xuat(string, int[][MAX], int, int);

int main()
{
	int b[100][100];
	int k, l;

	Nhap(b, k, l);
	cout << "Mang tran ban dau: " << endl;
	Xuat(b, k, l);

	string filename = "data01.inp";
	Xuat(filename, b, k, l);

	return 0;
}

void Nhap(int a[][100], int& m, int& n)
{
	cout << "Nhap so dong: ";
	cin >> m;
	cout << "Nhap so cot: ";
	cin >> n;

	srand(time(nullptr));

	for (int i = 0; i < m; i++)
	{
		for (int j = 0; j < n; j++)
			a[i][j] = (rand() % 201) - 100;
	}
}

void Xuat(int a[][100], int m, int n)
{
	for (int i = 0; i < m; i++)
	{
		for (int j = 0; j < n; j++)
			cout << setw(6) << a[i][j];
		cout << endl;
	}
}

void Xuat(string filename, int a[][MAX], int m, int n)
{
	ofstream myfile(filename);
	myfile << m << endl;
	myfile << n << endl;

	for (int i = 0; i < m; i++)
	{
		for (int j = 0; j < n; j++)
			myfile << setw(7) << a[i][j];
		myfile << endl;
	}
}