#include <iostream>
#include <cstdlib>
#include <ctime>
#include <iomanip>
using namespace std;

void Nhap(int[][100], int&, int&);
void Xuat(int[][100], int, int);
bool ktDang5m(int);
int Tong5m(int[][100], int, int, int);

int main()
{
	int b[100][100];
	int k, l;

	Nhap(b, k, l);
	cout << "Mang tran ban dau: " << endl;
	Xuat(b, k, l);


	int row;
	cout << "Nhap dong can tinh tong: ";
	cin >> row;

	cout << "Tong cac so nguyen co dang 5^m tren dong " << row << " la: " << Tong5m(b, k, l, row);

	return 0;
}

void Nhap(int a[][100], int& m, int& n)
{
	cout << "Nhap so dong: ";
	cin >> m;
	cout << "Nhap so cot: ";
	cin >> n;

	srand(time(nullptr));

	for (int i = 0; i < m; i++)
		for (int j = 0; j < n; j++)
			a[i][j] = rand() % 201 + 1;
}

void Xuat(int a[][100], int m, int n)
{
	for (int i = 0; i < m; i++)
	{
		for (int j = 0; j < n; j++)
			cout << setw(6) << a[i][j];
		cout << endl;
	}
}

bool ktDang5m(int n)
{
	int flag = 1;
	int t = n;
	while (t > 1)
	{
		int du = t % 5;
		if (du != 0)
			flag = 0;
		t = t / 5;
	}
	if (flag == 1)
		return true;
	else
		return false;
}

int Tong5m(int a[][100], int m, int n,int x)
{
	int s = 0;
	if (x >= n)
		cout << "So dong khong phu hop" << endl;
	else
	{
		for (int j = 0; j < n; j++)
		{
			if (ktDang5m(a[x][j]))
				s = s + a[x][j];
		}
	}
	return s;
}