#include <iostream>
#include <cmath>
using namespace std;
void Nhap(float&);
float LuyThua(float);
int main()
{
	float x;
	Nhap(x);
	float x7 = LuyThua(x);
	cout << "x^6 = " << x7;

	return 1;

}
float LuyThua(float k)
{
	float f = k * k;
	float f2 = f * f;
	float f4 = f2 * f2;
	float f6 = f4 * f2;
	float f7 = f6 * k;
	return f7;
}
void Nhap(float& x)
{
	cout << "Nhap x: ";
	cin >> x;
}