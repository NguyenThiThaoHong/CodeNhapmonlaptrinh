#include <iostream>
#include <cmath>
using namespace std;
float ktThuoc(float&,float&,float&,float&,float&,float&,float&,float&);
void Nhap(float&, float&, float&, float&, float&, float&, float&, float&);
float S(float a, float b, float c, float d, float e, float f);
int main()
{
	float xa, xb, xc, ya, yb, yc, xm, ym;
	Nhap(xa, xb, xc, ya, yb, yc, xm, ym);
	int kq= ktThuoc(xa, xb, xc, ya, yb, yc,xm,ym);
	if (kq==1)
		cout << "M thuoc tam giac";
	else
		cout << "M khong thuoc tam giac";
	return 1;
}
float S(float a, float b, float c, float d, float e, float f)
{
	float i = a * d + c * f + e * b - a * f - c * b - e * d;
	float S = (float)1 / 2 * abs(i);
	return S;
}
float ktThuoc(float& xA, float& xB, float& xC, float& yA, float& yB, float& yC,float& xM,float& yM)
{
	int flag = 0;
	float SABC = S(xA, yA, xB, yB, xC, yC);
	float SMAB = S(xM, yM, xA, yA, xB, yB);
	float SMBC = S(xM, yM, xB, yB, xC, yC);
	float SMCA = S(xM, yM, xC, yC, xA, yA);
	if (SABC == (SMAB + SMBC + SMCA))
		flag = 1;
	return flag;
}
void Nhap(float&xa, float&xb, float&xc, float&ya, float&yb, float&yc, float&xm, float&ym)
{
	cout << "Nhap xa: ";
	cin >> xa;
	cout << "Nhap xb: ";
	cin >> xb;
	cout << "Nhap xc: ";
	cin >> xc;
	cout << "Nhap ya: ";
	cin >> ya;
	cout << "Nhap yb: ";
	cin >> yb;
	cout << "Nhap yc: ";
	cin >> yc;
	cout << "Nhap xm: ";
	cin >> xm;
	cout << "Nhap ym: ";
	cin >> ym;
}