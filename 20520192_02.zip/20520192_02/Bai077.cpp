#include <iostream>
#include <cmath>
using namespace std;
int Tong(float, int);
void Nhap(int&, float&);
int main()
{
	int n;
	float x;
	Nhap(n, x);
	int kq = Tong(n,x);
	cout << "Tong cua n: " << kq;
	return 1;
}
int Tong(float y, int k)
{
	float s = 0;
	for (int i = 1; i <= k; i++)
	{
		s = s + pow(i, k);
	}
	return s;
}
void Nhap(int& n, float& x)
{
	cout << "Nhap n=";
	cin >> n;
	cout << "Nhap x=";
	cin >> x;
}
