#include <iostream>
#include <cmath>
using namespace std;
int DemChuSo(int);
void Nhap(int&);
int main()
{
	int n;
	Nhap(n);
	int kq = DemChuSo(n);
	cout << "dem chu so cua so nguyen n l� " << kq;
}
int DemChuSo(int k)
{
	int a = k;
	int Dem = 0;
	while (a != 0)
	{
		Dem = Dem + 1;
		a = a / 10;
	}
	return Dem;
}
void Nhap(int& n)
{
	cout << "Nhap n=";
	cin >> n;
}

