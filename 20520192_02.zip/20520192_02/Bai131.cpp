#include <iostream>
#include <cmath>
using namespace std;
void Nhap(float&, float&, float&,float &,float&,float&);
int ktTonTai(float, float, float);
int main()
{
	float xa, xb, xc, ya, yb, yc;
	Nhap(xa, xb, xc, ya, yb, yc);
	float AB = sqrt(pow(xb - xa, 2) + pow(yb - ya, 2));
	float AC = sqrt(pow(xc - xa, 2) + pow(yc - ya, 2));
	float BC = sqrt(pow(xc - xa, 2) + pow(yc - yb, 2));
	int kq = ktTonTai(AB, AC, BC);
	if (kq == 1)
		cout << "la 3 dinh cua tam giac";
	else 
		cout<<"khong la 3 dinh cua tam giac";
}
int ktTonTai(float a, float b, float c)
{
	int flag = 0;
	if (a + b > c && b + c > a && a + c > b)
		flag = 1;
	return flag;
}

void Nhap(float& xa, float& xb, float& xc, float& ya, float& yb, float& yc)
{
	cout << "Nhap xa: ";
	cin >> xa;
	cout << "Nhap xb: ";
	cin >> xb;
	cout << "Nhap xc: ";
	cin >> xc;
	cout << "Nhap ya: ";
	cin >> ya;
	cout << "Nhap yb: ";
	cin >> yb;
	cout << "Nhap yc: ";
	cin >> yc;
}