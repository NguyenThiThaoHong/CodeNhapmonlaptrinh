#define _USE_MATH_DEFINES
#include <iostream>
#include <cmath>
using namespace std;
float DienTich(float, float);
int main()
{
	float r;
	cout << "Nhap ban kinh: ";
	cin >> r;
	int n;
	cout << "Nhap n: ";
	cin >> n;

	float kq = DienTich(r, n);
	cout << "Chu vi noi tiep duong tron la: " << kq;
	return 1;
}
float DienTich(float k, float t)
{
	float S = (float)1 / 2 * t * pow(k, 2) * sin(2 * M_PI / t);
	return S;
}