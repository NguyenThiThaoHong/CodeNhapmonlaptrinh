#include <iostream>
#include <cmath>
using namespace std;
void Nhap(int&);
int ktDoiXung(int);
int main()
{
	int  n;
	Nhap(n);
	int kq=ktDoiXung(n);
	if (kq==1)
		cout << "Day la so doi xung";
	else
		cout << "Khong phai so doi xung";
	return 1;
}
int ktDoiXung(int a)
{
	a = abs(a);
	int dn = 0;
	int t = a;
	int flag = 0;
	while (t != 0)
	{
		int dv = t % 10;
		dn = dn * 10 + dv;
		t = t / 10;
	}
	if (dn == a)
		flag = 1;
	return flag;

}
void Nhap(int& n)
{
	cout << "nhap n = ";
	cin >> n;
}