#include <iostream>
#include <cmath>
using namespace std;
float Tong(float);
int main()
{
	float e = 1;
	float p = Tong(e);
	cout << "Tong la: " << p;
	return 1;
}
float Tong(float k)
{
	float S = 0, T = 1, e = 1;
	int M = 1, i = 1;
	while (e >= pow(10, -6))
	{
		T = T * k;
		M = M * i;
		e = T / M;
		S = S + e;
		i = i + 1;
	}
	return S;
}