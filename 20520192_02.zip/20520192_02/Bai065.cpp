#include <iostream>
#include <cmath>
using namespace std;
int NhoNhat(int);
void Nhap(int&);
int main()
{
	int n;
	Nhap(n);
	int kq = NhoNhat(n);
	cout << "Chu so nho nhat " << kq;
}
int NhoNhat(int k)
{
	int a = k;
	int lc = k % 10;
	while (a != 0)
	{
		int dv = a % 10;
		if (dv < lc)
			lc = dv;
		a = a / 10;
	}
	return lc;
}
void Nhap(int& n)
{
	cout << "Nhap n=";
	cin >> n;
}
