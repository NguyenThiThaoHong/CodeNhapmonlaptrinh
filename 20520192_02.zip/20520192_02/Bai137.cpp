#include <iostream>
#include <cmath>
using namespace std;
void Nhap(float&);
float TinhGiaTri(float);
int main()
{
	float x;
	Nhap(x);
	float kq = TinhGiaTri(x);
	cout << "gia tri la" << kq;
	return 1;
}
float TinhGiaTri(float a)
{
	float S = 0;
	if (a >= 5)
		S = 2 * pow(a, 2) + 5 * a + 9;
	else
		 S = -2 * pow(a, 2) + 4 * a - 9;
	return S;
}
void Nhap(float&x)
{
	cout << "nhap x = ";
	cin >> x;
}