#include <iostream>
#include <cmath>
using namespace std;
void Nhap(float&);
float LuyThua(float);
int main()
{
	float x;
	Nhap(x);
	float x14 = LuyThua(x);
	cout << "x^14 = " << x14;

	return 1;

}
float LuyThua(float k)
{
	float f2 = k * k;
	float f4 = f2 * f2;
	float f8 = f4 * f4;
	float f12 = f8 * f4;
	float f14 = f12 * f2;
	return f14;
}
void Nhap(float& x)
{
	cout << "Nhap x: ";
	cin >> x;
}