#include <iostream>
#include <cmath>
using namespace std;
void Nhap(float&);
float LuyThua(float);
int main()
{
	float x;
	Nhap(x);
	float x11 = LuyThua(x);
	cout << "x^11 = " << x11;

	return 1;

}
float LuyThua(float k)
{
	float f2 = k * k;
	float f4 = f2 * f2;
	float f8 = f4 * f4;
	float f10 = f8 * f2;
	float f11 = f10 * k;
	return f11;
}
void Nhap(float& x)
{
	cout << "Nhap x: ";
	cin >> x;
}