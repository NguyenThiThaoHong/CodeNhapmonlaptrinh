#include <iostream>
#include <cmath>
using namespace std;
void Nhap(int&);
float Fibo(int);
int main()
{
	int n;
	Nhap(n); 
	float kq = Fibo(n);
	cout << "Tong la: " << kq;
	return 1;
}
float Fibo(int k)
{
	int f0 = 1;
	int f1 = 1;
	int fn = 0;
	for (int i = 2; i <= k; i++)
	{
		fn = f1 + f0;
		f0 = f1;
		f1 = fn;
	}
	return fn;
}
void Nhap(int& n)
{
	cout << "Nhap n=";
	cin >> n;
}
