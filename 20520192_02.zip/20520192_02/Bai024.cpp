#include <iostream>
#include <cmath>
using namespace std;
void Nhap(int&);
int ChuSoHangTram(int);
int main()
{
	int n;
	Nhap(n);
	int kq = ChuSoHangTram(n);
	cout << "chu so hang chuc la :" << kq;
	return 1;
}
int ChuSoHangTram(int k)
{
	int ht = (k % 1000) / 100;
	return ht;
}

void Nhap(int& n)
{
	cout << "Nhap n: ";
	cin >> n;
}