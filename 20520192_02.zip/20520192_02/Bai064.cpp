#include <iostream>
#include <cmath>
using namespace std;
int LonNhat(int);
void Nhap(int&);
int main()
{
	int n;
	Nhap(n);
	int kq =LonNhat(n);
	cout << "Chu so lon nhat " << kq;
}
int LonNhat(int k)
{
	int a = k;
	int lc = k % 10;
	while (a != 0)
	{
		int dv = a % 10;
		if (dv > lc)
			lc = dv;
		a = a / 10;
	}
	return lc;
}
void Nhap(int& n)
{
	cout << "Nhap n=";
	cin >> n;
}

