#include <iostream>
#include <cmath>
using namespace std;
void Nhap(int&, int&);
int ucln(int,int);
int main()
{
	int  a,b;
	Nhap(a,b);
	int kq=ucln(a,b);
	cout << "uoc chung lon nhat la" << kq;
	return 1;
}
int  ucln(int a,int b)
{
	a = abs(a), b = abs(b);
	while (a * b != 0)
	{
		if (a > b)
			a = a - b;
		else
			b = b - a;
	}
	int c = a + b;
	return c;
}
void Nhap(int& a,int& b)
{
	cout << "nhap a = ";
	cin >> a;
	cout << "nhap b = ";
	cin >> b;
}