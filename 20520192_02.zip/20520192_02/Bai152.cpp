#include <iostream>
#include <cmath>
using namespace std;
void Nhap(int&);
int ktDang3m(int);
int main()
{
	int  n;
	Nhap(n);
	int kq = ktDang3m(n);
	if (kq == 1)
		cout << "co dang 3^m";
	else
		cout << "ko co dang 3^m ";
	return 1;
}
int ktDang3m(int a)
{
	int flag = 1;
	int t = a;
	int du = 0;
	while (t > 1)
	{
		du = t % 3;
		if (du != 0)
			flag = 0;
		t = t / 3;
	}
	return flag;
}
void Nhap(int& n)
{
	cout << "nhap n = ";
	cin >> n;
}