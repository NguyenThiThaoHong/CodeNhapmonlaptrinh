#include <iostream>
#include <cmath>
using namespace std;
int TichUocSo(int);
int main()
{
	int n;
	cout << "Nhap n: ";
	cin >> n;
	int kq = TichUocSo(n);
	cout << "Tich uoc so cua so nguyen n l� " << kq;
}
int TichUocSo(int k)
{
	int s = 1;
	for (int i = 1; i <= k; i++)
		if (k % i == 0)
			s *= i;
	return s;
}

