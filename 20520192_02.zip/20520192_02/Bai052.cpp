#include <iostream>
#include <cmath>
using namespace std;
int DemUocSo(int);
void Nhap(int&);
int main()
{
	int n;
	cout << "Nhap n: ";
	cin >> n;
	int kq = DemUocSo(n);
	cout << "so luong uoc so cua so nguyen n l� " << kq;
}
int DemUocSo(int k)
{
	int Dem = 0;
	for (int i = 1; i <= k; i++)
		if (k % i == 0)
			Dem += 1;
	return Dem;
}
void Nhap(int& n)
{
	cout << "Nhap n=";
	cin >> n;
}

