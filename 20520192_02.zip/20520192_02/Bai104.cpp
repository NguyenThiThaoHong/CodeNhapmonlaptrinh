#include <iostream>
#include <cmath>
using namespace std;
float Tong(float);
int main()
{
	float e = 1;
	float p = Tong(e);
	cout << "Tong la: " << p;
	return 1;
}
float Tong(float k)
{
	float s = 0;
	k = 1;
	int i = 1;
	while (k >= pow(10, -6))
	{
		k = (float)1 / (i*(i+1));
		s = s + k;
		i++;
	}
	return s;
}