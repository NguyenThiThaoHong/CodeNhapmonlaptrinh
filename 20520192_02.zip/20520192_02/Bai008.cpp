#define _USE_MATH_DEFINES
#include <iostream>
#include <cmath>
using namespace std;
float ChuVi(float,float);
int main()
{
	float r;
	cout << "Nhap ban kinh: ";
	cin >> r;
	int n;
	cout << "Nhap n: ";
	cin >> n;

	float kq = ChuVi(r, n);
	cout << "Chu vi noi tiep duong tron la: " << kq;
	return 1;
}
float ChuVi(float k, float t )
{
	float f = 2 * t * sin(M_PI / t);
	return f;
}