#include <iostream>
#include <cmath>
using namespace std;
int Tong(int);
void Nhap(int&);
int main()
{
	int n;
	Nhap(n);

	int kq = Tong(n);

	cout << "Tong cua n: " << kq;
	return 1;
}
int Tong(int k)
{
	int t = 0;
	for (int i = 1; i <= k; i++)
		t = t + i * (i + 1);
	return t;
}
void Nhap(int& n)
{
	cout << "Nhap n: ";
	cin >> n;
}
