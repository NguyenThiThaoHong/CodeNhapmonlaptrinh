#include <iostream>
#include <cmath>
using namespace std;
int DemChuSo(int);
void Nhap(int&);
int main()
{
	int n;
	Nhap(n);
	int kq = DemChuSo(n);
	cout << "Dem chu so le cua so nguyen n l� " << kq;
}
int DemChuSo(int k)
{
	int a = k;
	int Dem = 0;
	while (a != 0)
	{
		int dv = a % 10;
		if (dv%2!=0)
			Dem = Dem + 1;
	    a = a / 10;
	}
	return Dem;
}
void Nhap(int& n)
{
	cout << "Nhap n=";
	cin >> n;
}

