#include <iostream>
#include <cmath>
using namespace std;
float Tong(float, int);
void Nhap(int&, float&);
int main()
{
	float x;
	int n;	
	Nhap(n, x);
	float kq = Tong(x, n);
	cout << "Ket qua la: " << kq;
	return 1;
}
float Tong (float y, int k)
{
	int t = 1;
	int s = 0;
	for (int i = 1; i <= k; i++)
	{
		t = t * y;
		s = s + t;
	}
	return s;
}
void Nhap(int&n, float&x)
{
	cout << "Nhap n=";
	cin >> n;
	cout << "Nhap x=";
	cin >> x;
}
