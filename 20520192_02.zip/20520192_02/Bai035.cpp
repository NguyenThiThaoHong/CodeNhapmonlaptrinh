#include <iostream>
#include <cmath>
using namespace std;
int Tich(int);
void Nhap(int&);
int main()
{
	int n;
	Nhap(n);

	int kq = Tich(n);

	cout << "Tong cua n: " << kq;
	return 1;
}
int Tich(int k)
{
	int t = 1;
	for (int i = 1; i <= k; i++)
		t = t * i;
	return t;
}
void Nhap(int& n)
{
	cout << "Nhap n: ";
	cin >> n;
}
