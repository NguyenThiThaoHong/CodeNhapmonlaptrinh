#include <iostream>
#include <cmath>
using namespace std;
float DoF(float);
void Nhap(float&);
int main()
{
	float C;
	Nhap(C);
	float kq = DoF(C);
	cout << "Do C la: " << kq;
	return 1;
}
float DoF(float k)
{
	float f = (float)(9 * k / 5) + 32;
	return f;
}
void Nhap(float& C)
{
	cout << "Nhap C=";
	cin >> C;
}