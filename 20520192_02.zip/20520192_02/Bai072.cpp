#include <iostream>
#include <cmath>
using namespace std;
float Tong(int);
void Nhap(int&);
int main()
{
	int n;
	Nhap(n);
	float kq = Tong(n);
	cout << "Tong cua n: " << kq;
	return 1;
}
float Tong(int k)
{
	int m = 0;
	float s = 0;
	for (int i = 1; i <= k; i++)
	{
		m = m + i;
		s = s + (float) 1/m;
	}
	return s;
}
void Nhap(int& n)
{
	cout << "Nhap n=";
	cin >> n;
}