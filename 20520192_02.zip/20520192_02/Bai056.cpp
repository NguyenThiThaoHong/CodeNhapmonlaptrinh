#include <iostream>
#include <cmath>
using namespace std;
int DemUocChan(int);
void Nhap(n);
int main()
{
	int n;
	Nhap(n);
	int kq = DemUocChan(n);
	cout << "so luong uoc so chan cua so nguyen n l� " << kq;
}
int DemUocChan(int k)
{
	int Dem = 0;
	for (int i = 2; i <= k; i=i+2)
		if (k % i == 0)
			Dem += 1;
	return Dem;
}
void Nhap(int& n)
{
	cout << "Nhap n=";
	cin >> n;
}
