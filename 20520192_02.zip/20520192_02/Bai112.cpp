#include <iostream>
#include <cmath>
using namespace std;
float Tong(float);
int main()
{
	float e = 1;
	float p = Tong(e);
	cout << "Tong la: " << p;
	return 1;
}
float Tong(float k)
{
	float S = 4 - (2 / 4) - (1 / 5) - (1 / 6), T = 1;
	k = 1;
	int i = 1;
	while (k >= pow(10, -6))
	{
		T = T * 16;
		k = (float)(4 / (8 * i + 1) - 2 / (8 * i + 4) - 1 / (8 * i + 5) - 1 / (8 * i + 6));
		S = S + k;
		i = i + 1;
	}
	return S;
}