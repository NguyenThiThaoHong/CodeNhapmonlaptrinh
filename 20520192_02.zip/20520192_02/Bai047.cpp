#include <iostream>
#include <cmath>
using namespace std;
float Tong(int);
void Nhap(int&);
int main()
{
	int n;
	Nhap(n);

	float kq = Tong(n);

	cout << "Tong cua n: " << kq;
	return 1;
}
float Tong(int k)
{
	float t = 0;
	for (int i = 1; i <= k; i++)
		t += sqrt(1 + 1 / pow(i, 2) + 1 / pow(i + 1, 2));
	return t;
}
void Nhap(int& n)
{
	cout << "Nhap n: ";
	cin >> n;
}
