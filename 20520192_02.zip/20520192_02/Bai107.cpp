#include <iostream>
#include <cmath>
using namespace std;
float Tong(float,float );
int main()
{
	float x;
	cout << "Nhap x";
	cin >> x;
	float e = 1;
	float p = Tong(x,e);
	cout << "Tong la: " << p;
	return 1;
}
float Tong(float a,float e)
{
	float cosx = 1;
	e = 1;
	long T = 1, M = 1;
	int i = 2;
	float dau = -1;
	while (e >= pow(10, -6))
	{
		T = T * a * a;
		M = M * i * (i + 1);
		e = (float)T / M;
		cosx = dau * e + cosx;
		dau = -dau;
		i = i + 2;
	}
	return cosx;
}