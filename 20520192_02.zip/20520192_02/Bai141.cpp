#include <iostream>
#include <cmath>
using namespace std;
void Nhap(int&);
int csdt(int);
int main()
{
    int  n;
	Nhap(n);
	float kq = csdt(n);
	cout << "gia tri la" << kq;
	return 1;
}
int csdt(int a)
{
	int dt = abs(a);
	while (dt >= 10)
		dt = dt / 10;
	return dt;
}
void Nhap(int& n)
{
	cout << "nhap n = ";
	cin >> n;
}