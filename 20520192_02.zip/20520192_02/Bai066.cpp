#include <iostream>
#include <cmath>
using namespace std;
int TonTaiChan(int);
void Nhap(int&);
int main()
{
	int n;
	Nhap(n);
    int kq= TonTaiChan(n);
	if (kq == 1)
		cout << "ton tai so chan";
	else
		cout << "khong ton tai so chan";
	return 1;
}
int TonTaiChan(int k)
{
	int a = k;
	int flag = 0;
	while (a != 0)
	{
		int dv = a % 10;
		if (dv % 2 == 0)
			flag = 1;
		a = a / 10;
	}
	return flag;	
}
void Nhap(int& n)
{
	cout << "Nhap n=";
	cin >> n;
}
void Nhap(int& n)
{
	cout << "Nhap n=";
	cin >> n;
}
