#include <iostream>
#include <cmath>
using namespace std;
void Nhap(float&);
float DienTich(float);
int main()
{
	float r;
	Nhap(r);
	float kq = DienTich(r);
	cout << "Dien tich la: " << kq;
	return 1;
}
float DienTich(float r)
{
	float s = 3.14 * pow(r, 2);
	return s;
}
void Nhap(float& r)
{
	cout << "Nhap ban kinh: ";
	cin >> r;
}