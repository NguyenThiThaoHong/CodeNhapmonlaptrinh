#include <iostream>
#include <cmath>
using namespace std;
void Nhap(float&, float&, float&);
int ktTonTai(float, float, float);
int main()
{
	float a, b, c;
	Nhap(a, b, c);
	int kq=ktTonTai(a, b, c);
	if (kq==1)
		cout << "ton tai tam giac";
	else
		cout << "ko ton tai tam giac";
	return 1;
}
int ktTonTai(float a, float b, float c)
{
	int flag = 0;
	if (a + b > c && b + c > a && a + c > b)
		flag = 1;
	return flag;
}
void Nhap(float& a, float& b, float& c)
{
	cout << "Nhap a: ";
	cin >> a;
	cout << "Nhap b: ";
	cin >> b;
	cout << "Nhap c: ";
	cin >> c;
}