#include <iostream>
#include <cmath>
using namespace std;
int Tong(float, int);
void Nhap(int&, float&);
int main()
{
	int n;
	float x;
	Nhap(n, x);
	int kq = Tong(x, n);
	cout << "Tong cua n: " << kq;
	return 1;
}
int Tong(float y, int k)
{
	int t = 1;
	int m = 1;
	int s = y;
	for (int i = 1; i <= k; i++)
	{
		t = t * y;
		m = m * i;
		s = s + (float)t / m;
	}
	return s;
}
void Nhap(int& n, float& x)
{
	cout << "Nhap n=";
	cin >> n;
	cout << "Nhap x=";
	cin >> x;
}
