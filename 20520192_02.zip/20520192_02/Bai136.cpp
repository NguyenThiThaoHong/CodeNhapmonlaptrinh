#include <iostream>
#include <cmath>
using namespace std;
void LietKeNhuan(int, int);
void Nhap(int&, int&);
int main()
{
	int x, y;
	Nhap(x, y);
	LietKeNhuan(x, y);
	return 1;
}
void LietKeNhuan(int x, int y)
{
	cout << " cac nam nhuan trong doan tu " << x << " den " << y << " la:  ";

	for (int i = x; i <= y; i++)
	{
		int dk1 = ((i % 4 == 0) && (i % 100 != 0));
		int dk2 = (i % 400 == 0);
		if (dk1 or dk2)
			cout << i << " ";
	}
}
void Nhap(int& x, int& y)
{
	cout << "nhap x = ";
	cin >> x;
	cout << " nhap y = ";
	cin >> y;

}