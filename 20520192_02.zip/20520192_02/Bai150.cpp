#include <iostream>
#include <cmath>
using namespace std;
void Nhap(int&, int&);
int bcnn(int, int);
int main()
{
	int  a, b;
	Nhap(a, b);
	int kq=bcnn(a, b);
	cout << "boi chung nho nhat" << kq;
	return 1;
}
int  bcnn(int a, int b)
{
	int m = abs(a), n = abs(b);
	while (m * n != 0)
	{
		if (m > n)
			m = m - n;
		else
			n = n - m;
	}
	int kq = abs(a * b) / (m + n);
	return kq;
}
void Nhap(int& a, int& b)
{
	cout << "nhap a = ";
	cin >> a;
	cout << "nhap b = ";
	cin >> b;
}