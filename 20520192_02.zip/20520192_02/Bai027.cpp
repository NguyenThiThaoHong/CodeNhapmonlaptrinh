#include <iostream>
#include <cmath>
using namespace std;
int Tong(int);
void Nhap(int&);
int main()
{
	int n;
	Nhap(n);

	int kq = Tong(n);

	cout << "Tong cua n: " << kq;
	return 1;
}
int Tong(int k)
{
	int s = 0;
	for (int i = 1; i <= k; i++)
		s = s + i;
	return s;
}
void Nhap(int& n)
{
	cout << "Nhap n: ";
	cin >> n;
}