#include <iostream>
#include <cmath>
using namespace std;
void Nhap(int&);
int ChuSoHangChuc(int);
int main()
{
	int n;
	Nhap(n);
	int kq = ChuSoHangChuc(n);
	cout << "chu so hang chuc la :" << kq;
	return 1;
}
int ChuSoHangChuc(int k)
{
	int hc = (k / 10) % 10;
	return hc;
}

void Nhap(int& n)
{
	cout << "Nhap n: ";
	cin >> n;
}