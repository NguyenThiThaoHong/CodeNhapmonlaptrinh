#include <iostream>
#include <cmath>
using namespace std;
int TongUocSo(int);
int main()
{
	int n;
	Nhap(n);
	int kq=TongUocSo(n);
	cout << "Tong uoc so cua so nguyen n l� " << kq;
}
int TongUocSo(int k)
{
	int s = 0;
	for (int i = 1; i <= k; i++)
		if (k % i == 0)
		     s +=  i;
	return s;
}
void Nhap(int& n)
{
	cout << "Nhap n: ";
	cin >> n;
}


