#include <iostream>
#include <cmath>
using namespace std;
float Tong(float, int);
void Nhap(int&, float&);
int main()
{
	int n;
	float x;
	Nhap(n, x);
	float kq = Tong(x, n);
	cout << "Tong cua n: " << kq;
	return 1;
}
float Tong(float y, int k)
{
	float s = 0;
	float t = y;
	for (int i = 1; i <= k; i = i + 1)
	{
		t = sin(t);
		s = s + t;
	}
	return s;
}
void Nhap(int& n, float& x)
{
	cout << "Nhap n=";
	cin >> n;
	cout << "Nhap x=";
	cin >> x;
}
