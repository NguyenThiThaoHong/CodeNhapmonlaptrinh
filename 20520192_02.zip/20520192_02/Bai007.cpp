#include <iostream>
#include <cmath>
using namespace std;
float DoC(float);
void Nhap(float&);
int main()
{
	float F;
	Nhap(F);

	float kq = DoC(F);
	cout << "Do C la: " << kq;
	return 1;
}
float DoC(float k)
{
	float f = (float)(5 * k / 9) - 32;
	return f;
}
void Nhap(float& F)
{
	cout << "Nhap F=";
	cin >> F;
}