#include <iostream>
#include <cmath>
using namespace std;
void Nhap(float&, float&,float&);
void XuatTang(float&, float&,float&);
int main()
{
	float a, b,c;
	Nhap(a, b,c);
	XuatTang(a, b,c);
	cout << "xuat tang hai so la :" << a << ";" << b << ";" << c;
	return 1;
}
void XuatTang(float& x, float& y,float& z)
{
	if (x > y)
	{
		float temp = x;
		x = y;
		y = temp;
	}

	if (x > z)
	{
		float temp = x;
		x = z;
		z = temp;
	}

	if (y > z)
	{
		float temp = y;
		y = z;
		z = temp;
	}
}
void Nhap(float& a, float& b,float& c)
{
	cout << "Nhap a: ";
	cin >> a;
	cout << "Nhap b: ";
	cin >> b;
	cout << "Nhap c: ";
	cin >> c;
}
