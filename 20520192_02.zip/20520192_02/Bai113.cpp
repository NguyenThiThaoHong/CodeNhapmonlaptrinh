#include <iostream>
#include <cmath>
using namespace std;
float TinhAn(int);
void Nhap(int&);
int main()
{
	int n;
	Nhap(n);
	float kq = TinhAn(n);
	cout << "Tong cua n: " << kq;
	return 1;
}
float TinhAn(int k)
{
	int at = 2;
	int ahh = 0;
	for (int i = 2; i <= k; i++)
	{
	    ahh = at + 2 * i + 1;
		at = ahh;
	}
	return ahh;
}
void Nhap(int& n)
{
	cout << "Nhap n=";
	cin >> n;
}
