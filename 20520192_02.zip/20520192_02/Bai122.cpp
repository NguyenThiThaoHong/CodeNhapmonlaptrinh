﻿#include <iostream>
#include <cmath>
using namespace std;
float TinhAn(int);
float TinhBn(int);
void Nhap(int&);
int main()
{
	int n;
	Nhap(n);
	float kq = TinhAn(n);
	float kq1 = TinhBn(n);
	cout << "SO HANG THU N LA : gia tri a " << kq <<"gia tri b "<< kq1;
	return 1;
}
float TinhAn(int k)
{
	int at = 1;
	int bt = 1;
	int ahh = 0, bhh = 0;
	for (int i = 2; i <= k; i++)
	{
		ahh = 3 * bt + 2 * at;
		at= ahh;
	}
	return ahh;
}
float TinhBn(int k)
{
	int at = 1;
	int bt = 1;
	int ahh = 0, bhh = 0;
	for (int i = 2; i <= k; i++)
	{
		bhh = at + 3 * bt;
		bt = bhh;
	}
	return bhh;
}
void Nhap(int& n)
{
	cout << "Nhap n=";
	cin >> n;
}

