#include <iostream>
#include <cmath>
using namespace std;
void Nhap(int&);
int ChuSoDonVi(int);
int main()
{
	int n;
	Nhap(n);
	int kq = ChuSoDonVi(n);
	cout << "chu so hang don vi la :" << kq;
	return 1;
}
int ChuSoDonVi(int k)
{
	int dv = k % 10;
	return dv;
}

void Nhap(int& n)
	{
		cout << "Nhap n: ";
		cin >> n;
	}