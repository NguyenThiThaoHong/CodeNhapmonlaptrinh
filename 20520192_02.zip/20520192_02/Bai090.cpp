#include <iostream>
#include <cmath>
using namespace std;
float Tong(float, int);
void Nhap(int&, float&);
int main()
{
	int n;
	float x;
	Nhap(n, x);
	float kq = Tong(x, n);
	cout << "Tong cua n: " << kq;
	return 1;
}
float Tong(float y, int k)
{
	float s = 0;
	int t = 1;
	int m = 1;
	int dau = -1;
	for (int i = 1; i <= k; i = i + 1)
	{
		t = t * y;
		m = m * i;
		s = s + dau * (float)t / m;
		dau = -dau;
	}
	return s;
}
void Nhap(int& n, float& x)
{
	cout << "Nhap n=";
	cin >> n;
	cout << "Nhap x=";
	cin >> x;
}
