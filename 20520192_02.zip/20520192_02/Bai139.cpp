#include <iostream>
#include <cmath>
using namespace std;
void Nhap(float&,float&);
float TinhGiaTri(float,float,int&);
int main()
{
	float a,b;
	Nhap(a,b);
	int flag;
	float kq = TinhGiaTri(a,b,flag);
	if (flag == 1)
		cout << "VSN";
	if (flag == 2)
		cout << "VN";
	if (flag == 3)
	{
		float x = TinhGiaTri(a, b, flag);
		cout << "nghiem x=" << x;
	}
	return 1;
}
float TinhGiaTri(float a,float b,int& flag)
{
	float x = 0;
	if (a == 0)
	{
		if (b == 0)
			 flag = 1;
		else
			 flag = 2;
	}
	else
	{
		flag = 3;
		x = -b / a;
	}
	return x;
}
void Nhap(float& a,float &b)
{
	cout << "nhap a = ";
	cin >> a;
	cout << "nhap b = ";
	cin >> b;
}