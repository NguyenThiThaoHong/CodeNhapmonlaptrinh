#include <iostream>
#include <cmath>
using namespace std;
void Nhap(int&);
int ktToanLe(int);
int main()
{
	int  n;
	Nhap(n);
	int kq=ktToanLe(n);
	if (kq == 1)
		cout << "Toan le";
	else
		cout << "Khong toan le";
	return 1;
}
int  ktToanLe(int a)
{
	a = abs(a);
	int flag = 1;
	int t = a;
	while (t != 0)
	{
		int dv = t % 10;
		if (dv % 2 == 0)
			flag = 0;
		t = t / 10;
	}
	return flag;
}
void Nhap(int& n)
{
	cout << "nhap n = ";
	cin >> n;
}