#include <iostream>
#include <cmath>
using namespace std;
void LietKeUocLe(int);
void Nhap(int&);
int main()
{
	int n;
	Nhap(n);
	LietKeUocLe(n);
}
void LietKeUocLe(int k)
{
	for (int i = 1; i <= k; i=i+2)
		if (k % i == 0)
			cout << i << ";";
}
void Nhap(int& n)
{
	cout << "Nhap n=";
	cin >> n;
}

