#include <iostream>
#include <cmath>
using namespace std;
void Nhap(int&);
int ktChinhPhuong(int);
int main()
{
	int  n;
	Nhap(n);
	int kq=ktChinhPhuong(n);
	if (kq == 1)
		cout << "Day la so chinh phuong";
	else
		cout << "Day khong phai la so chinh phuong";

	return 1;
}
int ktChinhPhuong(int a)
{
	int flag = 0;
	int i = 0;
	while (i <= a)
	{
		if (pow(i, 2) == a)
			flag = 1;
		i = i + 1;
	}
	return flag;
}
void Nhap(int& n)
{
	cout << "nhap n = ";
	cin >> n;
}