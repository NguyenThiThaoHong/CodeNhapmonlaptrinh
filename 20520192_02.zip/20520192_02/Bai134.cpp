#include <iostream>
#include <cmath>
using namespace std;
int ktBatDangThuc(float, float, float);
void Nhap(float&, float&, float&);
int main()
{
	float x, y, z;
	Nhap(x, y, z);
	int kq=ktBatDangThuc(x, y, z);
	if (kq==1)
		cout << "Bat dang thuc dung";
	else
		cout << "bat dang thuc ko dung";
}
int ktBatDangThuc(float a, float b, float c)
{
	int flag = 0;
	if (a <= b && b <= c)
		flag = 1;
	return flag;
}
void Nhap(float&x, float&y, float&z)
{
	cout << "Nhap x: ";
	cin >> x;
	cout << "Nhap y: ";
	cin >> y;
	cout << "Nhap z: ";
	cin >> z;

}
