#include <iostream>
#include <cmath>
using namespace std;
void Nhap(float&, float&,float &);
float TinhGiaTri(float, float,float,float&,float&);
int main()
{
	float a, b,c;
	Nhap(a, b,c);
	float x1, x2;
	float kq = TinhGiaTri(a, b, c, x1, x2);
	if (kq == 1)
		cout << "phuong trinh co 2  nghiem " << x1 << ";" << x2;
	if (kq == 2)
		cout << "phuong trinh vo ngiem";
	if (kq == 3)
		cout << "phuong trinh co nghiem kep" << x1;
	return 1;
}
float TinhGiaTri(float a, float b,float c,float& x1,float& x2)
{
	float dt = pow(b, 2) - 4 * a * c;
	if (dt != 0)
		if (dt > 0)
		{
			float x1 = (-b + sqrt(dt)) / (2 * a);
			float x2 = (-b - sqrt(dt)) / (2 * a);
			return 1;
		}
		else
		{
				return 2;
		}
	else
	{
		 x1=x2 = -b / 2 * a;
		return 3;
	}
}
void Nhap(float& a, float& b, float& c)
{
	cout << "nhap a = ";
	cin >> a;
	cout << "nhap b = ";
	cin >> b;
	cout << "nhap c = ";
	cin >> c;
}