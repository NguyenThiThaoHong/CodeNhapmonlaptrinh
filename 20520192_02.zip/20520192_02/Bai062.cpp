#include <iostream>
#include <cmath>
using namespace std;
int TongSoChan(int);
void Nhap(int&);
int main()
{
	int n;
	Nhap(n);
	int kq = TongSoChan(n);
	cout << "Tich chu so cua so nguyen n l� " << kq;
}
int TongSoChan(int k)
{
	int a = k;
	int s = 0;
	while (a != 0)
	{
		int dv = a % 10;
		if (dv%2==0) 
		s = s + dv;
		a = a / 10;
	}
	return s;
}
void Nhap(int& n)
{
	cout << "Nhap n=";
	cin >> n;
}


