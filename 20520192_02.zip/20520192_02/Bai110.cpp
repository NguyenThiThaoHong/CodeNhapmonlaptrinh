#include <iostream>
#include <cmath>
using namespace std;
float Tong(float);
int main()
{
	float e = 1;
	float p = Tong(e);
	cout << "Tong la: " << p;
	return 1;
}
float Tong(float k)
{
	float S = 0, T = 1;
	k = 1;
	int  i = 1, dau = 1;
	while (k >= pow(10, -6))
	{
		k = (float)4 / i;
		S = S + dau * k;
		i = i + 2;
		dau = -dau;
	}
	return S;
}