#include <iostream>
#include <cmath>
using namespace std;
void Nhap(float&);
float LuyThua(float);
int main()
{
	float x;
	Nhap(x);
	float x15 = LuyThua(x);
	cout << "x^15 = " << x15;

	return 1;

}
float LuyThua(float k)
{
	float f2 = k * k;
	float f3 = k * f2;
	float f5 = f3 * f2;
	float f10 = f5 * f5;
	float f15 = f10 * f5;
	return f15;
}
void Nhap(float& x)
{
	cout << "Nhap x: ";
	cin >> x;
}