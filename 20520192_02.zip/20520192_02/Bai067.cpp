#include <iostream>
#include <cmath>
using namespace std;
int TonTaiLe(int);
void Nhap(int&);
int main()
{
	int n;
	Nhap(n);
	int kq = TonTaiLe(n);
	if (kq == 1)
		cout << "ton tai le";
	else
		cout << "ko ton tai le";

	return 1;
}
int TonTaiLe(int k)
{
	int a = k;
	int flag = 0;
	while (a != 0)
	{
		int dv = a % 10;
		if (dv % 2 != 0)
			flag = 1;
		a = a / 10;
	}
	return flag;
}
void Nhap(int& n)
{
	cout << "Nhap n=";
	cin >> n;
}

