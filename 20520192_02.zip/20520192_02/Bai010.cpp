#include <iostream>
#include <cmath>
using namespace std;
void Nhap(float&, float&, float&, float&, float&, float&);
float KhoangCach(float, float, float, float);
int main()
{
	float x1, y1, x2, y2, x3, y3;
	Nhap(x1, y1, x2, y2, x3, y3);
	float kc1 = KhoangCach(x1, y1, x2, y2);
	float kc2 = KhoangCach(x3, y3, x2, y2);
	float kc3 = KhoangCach(x1, y1, x3, y3);
	float P = kc1 + kc2 + kc3;

	cout << "Chu vi tam giac la: " << P;
	return 1;
}
float KhoangCach(float z1, float t1, float z2, float t2)
{
	return sqrt((z2 - z1) * (z2 - z1) + (t2 - t1) * (t2 - t1));
}
void Nhap(float& x1, float& y1, float& x2, float& y2, float& x3, float& y3)
{
	cout << "Nhap x1: ";
	cin >> x1;
	cout << "Nhap y1: ";
	cin >> y1;
	cout << "Nhap x2: ";
	cin >> x2;
	cout << "Nhap y2: ";
	cin >> y2;
	cout << "Nhap x3: ";
	cin >> x3;
	cout << "Nhap y3: ";
	cin >> y3;
}