#include <iostream>
#include <cmath>
using namespace std;
void Nhap(float&, int&);
float Tong(float, int);
int main()
{
	int n;	
	float x;
	Nhap(x, n);
	float kq = Tong(x, n);
	cout << "Tong cua n: " << kq;
	return 1;
}
float Tong(float x, int k)
{
	float t = 1;
	for (int i = 1; i <= k; i++)
		t = t * (x + i);
	return t;
}
void Nhap(float&x,int& n)
{
	cout << "Nhap x: ";
	cin >> x;
	cout << "Nhap n: ";
	cin >> n;
}
