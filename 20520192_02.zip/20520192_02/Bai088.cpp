#include <iostream>
#include <cmath>
using namespace std;
float Tong(int);
void Nhap(int&);
int main()
{
	int n;
	Nhap(n);
	float kq = Tong(n);
	cout << "Tong cua n: " << kq;
	return 1;
}
float Tong(int k)
{
	float s = 0;
	int t = 0;
	int dau = 1;
	for (int i = 1; i <= k; i = i + 1)
	{
		t = t * i;
		s = s + dau* (float) 1/ t;
		dau = -dau;
	}
	return s;
}void Nhap(int& n)
{
	cout << "Nhap n=";
	cin >> n;
}
