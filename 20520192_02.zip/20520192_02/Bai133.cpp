#include <iostream>
#include <cmath>
using namespace std;
void Nhap(float&, float&, float&);
int DinhDang(float, float, float);
int main()
{
	float a, b, c;
	Nhap(a, b, c);
	int kq = DinhDang(a, b, c);
	switch (kq)
	{
	      case 1: cout << "Tam giac vuong can";
			  break;
		  case 2: cout << "Tam giac vuong";
			  break;
		  case 3: cout << "Tam giac thuong";
			  break;
		  case 4: cout << "Tam giac deu";
			  break;
		  case 5:cout << "Tam giac can";
			  break;
		  case 6:cout << "khong ton tai tam giac";
			  break;
	}
	return 0;
}
int DinhDang(float x, float y, float z)
{
	if (x > abs(y - z) && x < y + z)
	{
		if (pow(x, 2) == pow(y, 2) + pow(z, 2) || pow(y, 2) == pow(z, 2) + pow(x, 2) || pow(z, 2) == pow(y, 2) + pow(x, 2))
		{
			if (x == y || y == z || z == x)
				return 1;
			else
				return 2;
		}
		else if (x != y && y != z && z != x)
			return 3;
		else
		{
			if (x == y && y == z && z == x)
				return 4;
			else
				return 5;
		}
	}
	else
		return 6;
}
void Nhap(float& a, float& b, float& c)
{
	cout << "Nhap a: ";
	cin >> a;
	cout << "Nhap b: ";
	cin >> b;
	cout << "Nhap c: ";
	cin >> c;
}
