#include <iostream>
#include <cmath>
using namespace std;
void Nhap(float&, float&);
void XuatTang(float&, float&);
int main()
{
	float a, b;
	Nhap(a, b);
	XuatTang(a, b);
	cout << "xuat tang hai so la :" << a << ";" << b;
	return 1;
}
void XuatTang(float& t, float& z)
{
	if (t > z)
	{
		float temp = t;
		t = z;
		z = temp;
	}
}
void Nhap(float& a, float& b)
{
	cout << "Nhap a: ";
	cin >> a;
	cout << "Nhap b: ";
	cin >> b;
}