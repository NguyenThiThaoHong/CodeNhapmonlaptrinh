#include <iostream>
#include <cmath>
using namespace std;
int TichUocLe(int);
void Nhap(int&);
int main()
{
	int n;
	Nhap(n);
	int kq = TichUocLe(n);
	cout << "Tich uoc so le cua so nguyen n l� " << kq;
}
int TichUocLe(int k)
{
	int s = 1;
	for (int i = 1; i <= k; i=i+2)
		if (k % i == 0)
			s *= i;
	return s;
}
void Nhap(int& n)
{
	cout << "Nhap n=";
	cin >> n;
}

