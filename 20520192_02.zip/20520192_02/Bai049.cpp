#include <iostream>
#include <cmath>
using namespace std;
void Nhap(int&);
void LietKe(int);
int main()
{
	int n;
	Nhap(n);
	LietKe(n);
}
void LietKe(int k)
{
	for (int i = 1; i <= k; i++)
		if (k % i == 0)
			cout << i << ";";
}
void Nhap(int& n)
{
	cout << "Nhap n: ";
	cin >> n;
}

	  
