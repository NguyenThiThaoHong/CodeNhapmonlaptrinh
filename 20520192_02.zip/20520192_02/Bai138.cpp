#include <iostream>
#include <cmath>
using namespace std;
void Nhap(float&);
float TinhGiaTri(float);
int main()
{
	float x;
	Nhap(x);
	float kq = TinhGiaTri(x);
	cout << "gia tri la" << kq;
	return 1;
}
float TinhGiaTri(float a)
{
	float S = 0;
	if (a >= 0)
	{
		if (a <= 1)
			S = 5 * a - 7;
		else
			S = 2 * pow(a, 3) + 5 * pow(a, 2) - 8 * a + 3;
	}
	else
		S = -2 * pow(a, 3) + 6 * a + 9;
	return S;
}
void Nhap(float& x)
{
	cout << "nhap x = ";
	cin >> x;
}