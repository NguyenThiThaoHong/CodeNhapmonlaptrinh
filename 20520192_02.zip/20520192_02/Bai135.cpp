#include <iostream>
#include <cmath>
using namespace std;
void Nhap(int&);
int ktNhuan(int);
int main()
{
	int n;
	Nhap(n);
	int kq=ktNhuan(n);
	if (kq==1)
		cout << "nam nhuan";
	else
		cout << "ko phai nam nhuan";
}
int ktNhuan(int a)
{
	int flag = 0;
	if (a % 400 == 0 || (a % 4 == 0 && a % 100 != 0))
		flag = 1;
	return flag;
}
void Nhap(int& n)
{
	cout << "Nhap nam :";
	cin >> n;
}
