#include <iostream>
#include <cmath>
using namespace std;
void Nhap(int&);
int ktToanChan(int);
int main()
{
	int  n;
	Nhap(n);
	int kq=ktToanChan(n);
	if (kq == 0)
		cout << "toan chan";
	else
		cout << "ko toan chan";

	return 1;
}
int  ktToanChan(int a)
{
	int flag = 0, t = a, dv = 0;
	while (t != 0)
	{
		dv = t % 10;
		if (dv % 2 != 0)
			flag = 1;
		t = t / 10;
	}
	return flag;
}
void Nhap(int& n)
{
	cout << "nhap n = ";
	cin >> n;
}