#include <iostream>
#include <cmath>
using namespace std;
void Nhap(int&);
int ktNguyenTo(int);
int main()
{
	int  n;
	Nhap(n);
	int kq= ktNguyenTo(n);
	if (kq==1)
		cout << "so NT";
	else
		cout << "ko so NT";

	return 1;
}
int ktNguyenTo(int a)
{
	int flag = 0;
	int i = 1;
	int dem = 0;
	while (i <= a)
	{
		if (a % i == 0)
			dem = dem + 1;
		i = i + 1;
	}
	if (dem == 2)
		flag = 1;
	return flag;
}
void Nhap(int& n)
{
	cout << "nhap n = ";
	cin >> n;
}