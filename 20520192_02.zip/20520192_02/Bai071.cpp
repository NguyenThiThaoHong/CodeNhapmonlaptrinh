#include <iostream>
#include <cmath>
using namespace std;
float Tong(float, int);
void Nhap(int&, float&);
int main()
{
	float x;
	int n;
	Nhap(n, x);
	float kq = Tong(x, n);
	cout << "Ket qua la: " << kq;
	return 1;
}
float Tong(float y, int k)
{
	int t = y;
	int s = y;
	for (int i = 3; i <= 2*k+1; i=i+2)
	{
		t = t * y*y;
		s = s + t;
	}
	return s;
}
void Nhap(int& n, float& x)
{
	cout << "Nhap n=";
	cin >> n;
	cout << "Nhap x=";
	cin >> x;
}
