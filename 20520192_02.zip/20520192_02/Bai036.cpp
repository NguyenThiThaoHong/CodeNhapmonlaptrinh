#include <iostream>
#include <cmath>
using namespace std;
float luyThua(float, int);
void Nhap(float&, int&);
int main()
{
	float x;
	int n;
	Nhap(x, n);
	float kq = luyThua(x, n);

	cout << "Ket qua la: " << kq;

	return 1;
}
float luyThua(float y, int k)
{
	int t = 1;
	for (int i = 1; i <= k; i++)
		t = t * y;
	return t;
}
void Nhap(float&x,int& n)
{
	cout << "Nhap x: ";
	cin >> x;
	cout << "Nhap n: ";
	cin >> n;
}

