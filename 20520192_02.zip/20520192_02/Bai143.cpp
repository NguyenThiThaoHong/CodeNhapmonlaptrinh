#include <iostream>
#include <cmath>
using namespace std;
void Nhap(int&);
int ktHoanThien(int);
int main()
{
	int  n;
	Nhap(n);
	int kq = ktHoanThien(n);
	if (kq==1)
		cout << "Day la so hoan thien";
	else
		cout << "Khong phai so hoan thien";
	return 1;
}
int ktHoanThien(int a)
{
	int flag = 0;
	int S = 0, i = 1;
	while (i < a)
	{
		if (a % i == 0)
			S = S + i;
		i = i + 1;
	}
	if (S == a)
		flag = 1;
	return flag;
}
void Nhap(int& n)
{
	cout << "nhap n = ";
	cin >> n;
}