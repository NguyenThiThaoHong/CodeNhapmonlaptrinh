#include <iostream>
#include <cmath>
using namespace std;
void Nhap(int&);
int DaoNguoc(int);
int main()
{
	int  n;
	Nhap(n);
	float kq = DaoNguoc(n);
	cout << "gia tri la" << kq;
	return 1;
}
int DaoNguoc(int a)
{
	a = abs(a);
	int dn = 0;
	int t = a;
	while (t != 0)
	{
		int dv = t % 10;
		dn = dn * 10 + dv;
		t = t / 10;
	}
	return dn;
}
void Nhap(int& n)
{
	cout << "nhap n = ";
	cin >> n;
}