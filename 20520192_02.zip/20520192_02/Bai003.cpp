#include <iostream>
#include <cmath>
using namespace std;
float ChuVi(float);
void Nhap(float&);
int main()
{
	float r;
	Nhap(r);
	float kq = ChuVi(r);
	cout << "Chu vi la: " << kq;
	return 1;
}
float ChuVi(float r)
{
	float p = 2 * 3.14 * r;
	return p;
}
void Nhap(float& r)
{
	cout << "Nhap ban kinh: ";
	cin >> r;
}