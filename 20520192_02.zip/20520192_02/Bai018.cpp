#include <iostream>
#include <cmath>
using namespace std;
void Nhap(float&);
float LuyThua(float);
int main()
{
	float x;
	Nhap(x);
	float x12 = LuyThua(x);
	cout << "x^12 = " << x12;

	return 1;

}
float LuyThua(float k)
{
	float f2 = k * k;
	float f3 = k * f2;
	float f6 = f2 * f3;
	float f12 = f6 * f6;
	return f12;
}
void Nhap(float& x)
{
	cout << "Nhap x: ";
	cin >> x;
}