#include <iostream>
#include <cmath>
using namespace std;
void Nhap(int&);
int ktDang5m(int);
int main()
{
	int  n;
	Nhap(n);
	int kq = ktDang5m(n);
	if (kq == 1)
		cout << "co dang 5^m";
	else
		cout << "ko co dang 5^m ";
	return 1;
}
int ktDang5m(int a)
{
	int flag = 1;
	int t = a;
	int du = 0;
	while (t > 1)
	{
		du = t % 5;
		if (du != 0)
			flag = 0;
		t = t / 5;
	}
	return flag;
}
void Nhap(int& n)
{
	cout << "nhap n = ";
	cin >> n;
}