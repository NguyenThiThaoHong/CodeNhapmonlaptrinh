#include <iostream>
#include <cmath>
using namespace std;
int TichChuSo(int);
int main()
{
	int n;
	Nhap(n);
	int kq = TichChuSo(n);
	cout << "Tich chu so cua so nguyen n l� " << kq;
}
int TichChuSo(int k)
{
	int a = k;
	int s = 1;
	while (a != 0)
	{
		int dv = a % 10;
		s = s * dv;
		a = a / 10;
	}
	return s;
}
void Nhap(int& n)
{
	cout << "Nhap n=";
	cin >> n;
}

