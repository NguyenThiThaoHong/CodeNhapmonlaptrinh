#include <iostream>
#include <cmath>
using namespace std;
float DienTichXungQuanh(float);
void Nhap(float&);
int main()
{
	float r;
	Nhap(r);
	float kq = DienTichXungQuanh(r);
	cout << "DienTichXungQuanh la: " << kq;
	return 1;
}
float DienTichXungQuanh(float r)
{
	float s = 4 * 3.14 * r * r;
	return s;
}
void Nhap(float& r)
{
	cout << "Nhap ban kinh: ";
	cin >> r;
}