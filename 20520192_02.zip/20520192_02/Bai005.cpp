#include <iostream>
#include <cmath>
using namespace std;
float Thetich(float);
void Nhap(float&);
int main()
{
	float r;
	Nhap(r);

	float kq = Thetich(r);
	cout << "The tich la: " << kq;
	return 1;
}
float Thetich(float r)
{
	float v = (float)4 * 3.14 * r * r * r;
	return v;
}
void Nhap(float& r)
{
	cout << "Nhap ban kinh: ";
	cin >> r;
}