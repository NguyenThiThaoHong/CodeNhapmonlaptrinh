#include <iostream>
#include <cmath>
using namespace std;
int NhoNhat(int, int);
void Nhap(int&, int&);
int main()
{
	int a, b;
	Nhap(a, b);
	int kq = NhoNhat(a, b);
	cout << "so lon nhat la" << kq;
	return 1;
}
int NhoNhat(int x, int y)
{
	int lc = x;
	if (lc > y)
		lc = y;
	return lc;
}
void Nhap(int& a, int& b)
{
	cout << "Nhap a: ";
	cin >> a;
	cout << "Nhap b: ";
	cin >> b;
}
