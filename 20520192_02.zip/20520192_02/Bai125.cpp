#include <iostream>
#include <cmath>
using namespace std;
void BienDoi(int&, int&);
void Nhap(int&, int&);
int main()
{
	int a;
	int b;
	Nhap(a, b);
	BienDoi(a, b);
	cout << " a va b sau khi bien doi la: " << a << " " << b;
	return 1;
}
void BienDoi(int& a, int& b)
{
	if (a < 0)
		a = -a;
	if (b < 0)
		b = -b;
}
void Nhap(int& a, int& b)
{
	cout << "Nhap a: ";
	cin >> a;
	cout << "Nhap b: ";
	cin >> b;
}
